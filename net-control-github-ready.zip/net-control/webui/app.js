/* ==========================================================================
   Net Control — application logic
   VERSION 3.2
   --------------------------------------------------------------------------
   Runs entirely in the browser. Nothing leaves this machine.

   FOUR THINGS YOU CAN DO, chosen from the home menu:

     Record      Real operators read a script aloud. The recording IS the
                 transmission — no synthesis, so it sounds like people
                 because it is people.

     Compose     The computer writes the messages. Unlimited variety, no
                 recording session, spoken by the browser during playback.

     Play either One player handles both. Recorded audio runs through a
                 band-pass filter with a noise floor and squelch tails;
                 written messages are spoken aloud with the same treatment
                 alongside. Either way it should sound like a radio.

   The player is the point of the whole thing: it schedules messages with
   realistic gaps, keys up, plays, and drops carrier — so the silence between
   transmissions matters as much as the traffic.

   If anything fails at startup, a red banner appears at the top of the page
   with the reason, rather than the app silently doing nothing.
   ========================================================================== */

var NET_CONTROL_VERSION = '3.2';

(function () {
'use strict';

/* Show failures on the page. A blank, unresponsive interface tells you
   nothing; this tells you exactly what broke and where. */
function fail(where, err) {
  var msg = (err && err.message) ? err.message : String(err);
  var bar = document.getElementById('boot-error');
  if (!bar) {
    bar = document.createElement('div');
    bar.id = 'boot-error';
    bar.style.cssText =
      'position:fixed;top:0;left:0;right:0;z-index:9999;' +
      'background:#A32D26;color:#fff;padding:12px 18px;' +
      'font:13px/1.5 ui-monospace,monospace;white-space:pre-wrap';
    document.body.insertBefore(bar, document.body.firstChild);
  }
  bar.textContent += 'Problem in ' + where + ':\n  ' + msg +
    '\n\nTry a hard reload (Ctrl+Shift+R). If it persists, check that ' +
    'index.html, style.css and app.js are all the same version.\n';
  if (window.console) console.error(where, err);
}

window.addEventListener('error', function (e) {
  fail('the page', e.error || e.message);
});

/* index.html carries its own version marker. If it does not match this file,
   say so loudly — a half-updated set looks fine but behaves like the old one,
   and that is impossible to diagnose by eye. */
function checkVersions() {
  var badge = document.querySelector('.ver');
  var htmlVer = badge ? badge.textContent.replace(/[^0-9.]/g, '') : null;

  if (!htmlVer) {
    fail('the files',
      'index.html has no version marker, so it is an older copy. ' +
      'Replace index.html, style.css and app.js together.');
    return false;
  }
  if (htmlVer !== NET_CONTROL_VERSION) {
    fail('the files',
      'index.html is v' + htmlVer + ' but app.js is v' + NET_CONTROL_VERSION +
      '. These must match. Replace all three files — index.html, style.css ' +
      'and app.js — then reload with Ctrl+Shift+R.');
    return false;
  }

  /* Stylesheet check: if the masthead has no bottom border, style.css either
     failed to load or is an older copy. */
  var mast = document.querySelector('.mast');
  if (mast && getComputedStyle(mast).borderBottomWidth === '0px') {
    fail('the files',
      'style.css did not load, or is an older copy. Check it is in the same ' +
      'folder as index.html.');
  }
  return true;
}

// ==========================================================================
// CONFIGURATION
// ==========================================================================

var PRESETS = [
  { id:'routine', name:'Quiet routine day',
    blurb:'Position reports, radio checks, handovers. Nothing happens. This is what most real nets sound like.',
    occ:18, incident:0,  thread:10, dbl:3 },
  { id:'normal', name:'Normal patrol',
    blurb:'Mostly everyday traffic with the occasional sighting or breakdown.',
    occ:25, incident:12, thread:30, dbl:5 },
  { id:'busy', name:'Busy operations',
    blurb:'Heavy traffic, several situations at once, stations talking over each other.',
    occ:42, incident:25, thread:45, dbl:12 },
  { id:'night', name:'Night watch',
    blurb:'Long silences, short exchanges, weak signals.',
    occ:9,  incident:8,  thread:20, dbl:2 },
  { id:'training', name:'Training incident',
    blurb:'One situation builds across the session, with routine traffic around it.',
    occ:28, incident:30, thread:60, dbl:6 }
];

var LENGTHS = [
  { m:5,  label:'5 minutes',  note:'quick check' },
  { m:10, label:'10 minutes', note:'demo length' },
  { m:30, label:'30 minutes', note:'a shift' },
  { m:60, label:'1 hour',     note:'full exercise' }
];

var PEOPLE = [
  { n:2, label:'2 people',  note:'one patrol and base' },
  { n:4, label:'4 people',  note:'a small net' },
  { n:6, label:'6 people',  note:'a full patrol net' },
  { n:8, label:'8 people',  note:'with logistics and battalion' }
];

/* Topics group the underlying situations under names somebody would
   actually use to describe what their team is dealing with. */
var TOPICS = [
  { id:'checks',   name:'Radio checks and reports',
    note:'The everyday backbone of any net',
    items:['radio_check','signal_strength','position_report','nothing_to_report',
           'checkpoint_reached','hourly_report','status_update','arrival_report'] },
  { id:'movement', name:'Moving around',
    note:'Routes, permissions, running late',
    items:['movement_permission','route_confirm','route_change','obstacle_report',
           'hold_position','slow_progress','departure_report','return_to_base','rendezvous'] },
  { id:'supply',   name:'Supplies and equipment',
    note:'Water, batteries, fuel, breakdowns',
    items:['resupply_request','resupply_confirm','fuel_state','ration_state',
           'vehicle_fault','equipment_check','battery_low','recovery_arrived',
           'collection_point','wrong_supplies'] },
  { id:'people',   name:'People and shifts',
    note:'Headcounts, handovers, someone unwell',
    items:['headcount','shift_handover','sick_soldier','rest_request',
           'relief_timing','brief_reminder','task_complete'] },
  { id:'sightings',name:'Something spotted',
    note:'Vehicles, civilians, unusual activity',
    items:['unknown_vehicle','civilians_present','livestock_movement',
           'abandoned_object','aircraft_overhead','light_observed',
           'negative_contact','track_report'] },
  { id:'weather',  name:'Weather and ground',
    note:'Visibility, crossings, conditions',
    items:['weather_report','weather_forecast','river_crossing','visibility_report'] },
  { id:'comms',    name:'Radio problems',
    note:'Bad signal, repeats, relaying',
    items:['poor_signal','move_for_comms','relay_message','correction',
           'authentication','net_closedown','wait_out','wrong_station'] },
  { id:'orders',   name:'Orders and coordination',
    note:'Instructions passed and read back',
    items:['orders_acknowledgement','boundary_coordination','mutual_sighting',
           'pass_information','extend_patrol','lost_bearings'] }
];

var SIGNALS = [
  { id:'base',     label:'Strong'   },
  { id:'handheld', label:'Normal'   },
  { id:'distant',  label:'Weak'     },
  { id:'air',      label:'Aircraft' }
];

/* Radio character per signal type, used by the player's audio chain. */
var PROFILE = {
  base:     { lo:280, hi:3600, noise:0.020 },
  handheld: { lo:350, hi:3200, noise:0.045 },
  distant:  { lo:420, hi:2800, noise:0.110 },
  air:      { lo:300, hi:3800, noise:0.060 }
};

var CATS = [
  { name: 'Talking on the radio', items: [
    ['radio_check','Radio check',31],['signal_strength','Signal strength',18],
    ['poor_signal','Poor signal',22],['move_for_comms','Move for comms',14],
    ['relay_message','Relay message',16],['correction','Correction',13],
    ['authentication','Authentication',11],['net_closedown','Net closedown',9],
    ['wait_out','Wait, out',15],['wrong_station','Wrong station',8] ] },
  { name: 'Everyday reporting', items: [
    ['position_report','Position report',28],['nothing_to_report','Nothing to report',26],
    ['checkpoint_reached','Checkpoint reached',24],['hourly_report','Hourly report',17],
    ['return_to_base','Return to base',15],['departure_report','Departure',14],
    ['arrival_report','Arrival',12],['shift_handover','Shift handover',13],
    ['task_complete','Task complete',11],['status_update','Status update',16] ] },
  { name: 'Moving around', items: [
    ['movement_permission','Movement permission',19],['route_confirm','Route confirm',14],
    ['obstacle_report','Obstacle',13],['route_change','Route change',12],
    ['extend_patrol','Extend patrol',9],['hold_position','Hold position',11],
    ['rendezvous','Rendezvous',10],['slow_progress','Behind schedule',12],
    ['lost_bearings','Unsure of position',8] ] },
  { name: 'Supplies and kit', items: [
    ['resupply_request','Resupply request',18],['fuel_state','Fuel state',12],
    ['resupply_confirm','Resupply received',11],['wrong_supplies','Wrong supplies',7],
    ['ration_state','Ration state',9],['collection_point','Collection point',8],
    ['vehicle_fault','Vehicle fault',14],['equipment_check','Faulty equipment',11],
    ['battery_low','Battery low',10],['recovery_arrived','Recovery arrived',8] ] },
  { name: 'People', items: [
    ['headcount','Headcount',12],['sick_soldier','Person unwell',10],
    ['rest_request','Rest halt',9],['relief_timing','Relief timing',8],
    ['brief_reminder','Briefing reminder',7] ] },
  { name: 'Something spotted', items: [
    ['unknown_vehicle','Unknown vehicle',16],['civilians_present','Civilians present',13],
    ['livestock_movement','Livestock',8],['abandoned_object','Abandoned object',11],
    ['aircraft_overhead','Aircraft overhead',9],['light_observed','Lights observed',10],
    ['negative_contact','Negative contact',12],['track_report','Tracks found',9] ] },
  { name: 'Weather and working together', items: [
    ['weather_report','Weather',13],['weather_forecast','Weather warning',9],
    ['river_crossing','Crossing impassable',7],['visibility_report','Visibility',10],
    ['boundary_coordination','Boundary coordination',11],['mutual_sighting','Mutual sighting',9],
    ['pass_information','Pass information',12],['orders_acknowledgement','Orders read back',14] ] }
];

var INCIDENT = ['unknown_vehicle','civilians_present','abandoned_object',
  'aircraft_overhead','light_observed','track_report','vehicle_fault','sick_soldier'];

var ALL_STATIONS = [
  { cs:'ALPHA-1',   role:'Company command post',  prof:'base',     speaker:'' },
  { cs:'BRAVO-6',   role:'Forward patrol',        prof:'handheld', speaker:'' },
  { cs:'CHARLIE-3', role:'Patrol',                prof:'handheld', speaker:'' },
  { cs:'DELTA-2',   role:'Vehicle patrol',        prof:'handheld', speaker:'' },
  { cs:'ECHO-4',    role:'Patrol',                prof:'handheld', speaker:'' },
  { cs:'FOXTROT-5', role:'Logistics element',     prof:'base',     speaker:'' },
  { cs:'GOLF-7',    role:'Observation post',      prof:'distant',  speaker:'' },
  { cs:'HOTEL-9',   role:'Battalion watchkeeper', prof:'base',     speaker:'' }
];

var STATIONS = ALL_STATIONS.slice(0, 6);
var CH = { COMMAND: [], ADMIN: [] };
var PAIRS = [];

function refName(cs) {
  return cs.toLowerCase().replace(/[^a-z0-9]+/g, '') + '.wav';
}
var LINES = {
  radio_check: ['{B}, this is {A}, radio check, over.','{A}, {B}, strength five, over.','{B}, roger, out.'],
  position_report: ['{B}, this is {A}, location grid four two six eight, over.','{A}, {B}, roger, out.'],
  nothing_to_report: ['{B}, this is {A}, sitrep, nothing significant to report, over.','{A}, roger, out.'],
  checkpoint_reached: ['{B}, this is {A}, at checkpoint two, grid four three seven one, over.','{A}, {B}, roger, out.'],
  resupply_request: ['{B}, this is {A}, request water and batteries at next checkpoint, over.','{A}, {B}, wait, out.','{A}, {B}, resupply arranged for one four hundred, over.','{B}, wilco, out.'],
  unknown_vehicle: ['{B}, this is {A}, contact report to follow, over.','{A}, {B}, send it, over.','{A}, three vehicles moving north, grid four four six five, over.','{B}, roger, maintain observation, out.'],
  vehicle_fault: ['{B}, this is {A}, vehicle unserviceable at grid four two five nine, request recovery, over.','{A}, {B}, roger, recovery en route, hold position, over.','{B}, wilco, out.'],
  poor_signal: ['{B}, this is {A}, say again your last, over.','{A}, {B}, I say again, grid four five seven zero, over.','{B}, roger, out.'],
  hourly_report: ['{A}, this is {B}, send your hourly report, over.','{B}, {A}, all stations accounted for, nothing to report, over.','{A}, roger, out.'],
  weather_report: ['{B}, this is {A}, visibility dropping, fog in the valley, over.','{A}, roger, out.'],
  shift_handover: ['{B}, this is {A}, handing over the sector, over.','{A}, {B}, roger, taking over, out.'],
  obstacle_report: ['{B}, this is {A}, route blocked at grid four three eight four, over.','{A}, {B}, roger, use alternative route bravo, over.','{B}, wilco, out.'],
  headcount: ['{A}, this is {B}, send headcount, over.','{B}, {A}, one two personnel, all present, over.','{A}, roger, out.'],
  orders_acknowledgement: ['{A}, this is {B}, move to grid four six six two by one six hundred, over.','{B}, {A}, read back, move to grid four six six two by one six hundred, over.','{A}, correct, out.'],
  _default: ['{B}, this is {A}, message follows, over.','{A}, {B}, send it, over.','{A}, roger, out.']
};

var THREADS = ['unknown_vehicle','vehicle_fault','resupply_request','obstacle_report'];

/* Situations worth recording by hand: short, and they repeat constantly, so
   a handful of real takes lifts a whole session. */
var TAKEABLE = ['radio_check','position_report','nothing_to_report',
  'checkpoint_reached','hourly_report','shift_handover','poor_signal',
  'headcount','weather_report','resupply_request','unknown_vehicle',
  'vehicle_fault','obstacle_report','orders_acknowledgement'];

// ==========================================================================
// STATE
// ==========================================================================

var preset   = PRESETS[1];
var minutes  = 10;
var seedVal  = 42;
var nPeople  = 6;

var on       = {};      // situation id -> included
var topicsOn = {};      // topic id     -> included
var refs     = {};      // callsign     -> { url, secs }   (derived from assignment)

/* Voices are a POOL of recordings that belong to people, kept separate from
   the stations they play. That separation matters: one person can cover
   several stations, and you can re-cast who plays whom without re-recording
   anybody. `assign` maps a callsign to a voice id. */
var voices    = [];     // [{ id, name, url, secs }]
var assign    = {};     // callsign -> voice id
var autoVoice = true;   // let the app cast the parts
var library  = [];      // recorded exchanges
var take     = null;
var written  = null;    // last composed session (generated)

/* Your real exchanges, loaded from exchanges_curated.json. When this is
   populated the scheduler draws from it instead of the small built-in
   sample set, so the preview matches what your machine actually produced. */
var pool     = null;    // [{ scenario, units, transmissions:[{callsign,text}] }]
var poolName = '';
var session  = null;    // whatever the player is showing
var playSrc  = 'generated';

var recorder = null, recTarget = null, recTimer = null, meterRAF = null;

var $  = function (s, r) { return (r || document).querySelector(s); };
var $$ = function (s, r) { return Array.prototype.slice.call((r || document).querySelectorAll(s)); };

function rng(seed) {
  var s = seed >>> 0;
  return function () { s = (s * 1664525 + 1013904223) >>> 0; return s / 4294967296; };
}

function esc(s) {
  return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;')
                  .replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}

function mmss(s) {
  var m = Math.floor(s / 60), r = Math.floor(Math.abs(s) % 60);
  return (m < 10 ? '0' : '') + m + ':' + (r < 10 ? '0' : '') + r;
}

function download(name, text, mime) {
  var b = new Blob([text], { type: mime });
  var a = document.createElement('a');
  a.href = URL.createObjectURL(b);
  a.download = name;
  a.click();
  setTimeout(function () { URL.revokeObjectURL(a.href); }, 1000);
}

var DIGITS = ['Zero','One','Two','Three','Four','Five','Six','Seven','Eight','Nine'];

function cap(cs) {
  return String(cs).split(/[\s\-_]+/).filter(Boolean).map(function (p) {
    if (/^\d+$/.test(p)) {
      return p.split('').map(function (d) { return DIGITS[+d]; }).join(' ');
    }
    return p.charAt(0).toUpperCase() + p.slice(1).toLowerCase();
  }).join(' ');
}

function situationName(id) {
  for (var i = 0; i < CATS.length; i++) {
    for (var j = 0; j < CATS[i].items.length; j++) {
      if (CATS[i].items[j][0] === id) return CATS[i].items[j][1];
    }
  }
  return id;
}

function linesFor(id, a, b) {
  var t = LINES[id] || LINES._default;
  return t.map(function (s, i) {
    return { cs: (i % 2 === 0) ? a : b,
             text: s.replace(/\{A\}/g, cap(a)).replace(/\{B\}/g, cap(b)) };
  });
}

function chosen() {
  var picked = Object.keys(on).filter(function (k) { return on[k]; });
  if (!pool) return picked;
  /* Only offer situations the loaded file actually contains. */
  var have = poolScenarios();
  var live = picked.filter(function (k) { return have[k]; });
  return live.length ? live : Object.keys(have);
}

function busyWord(o) {
  return o < 14 ? 'Very quiet' : o < 22 ? 'Quiet'
       : o < 33 ? 'Normal' : o < 45 ? 'Busy' : 'Very busy';
}

function profOf(cs) {
  for (var i = 0; i < STATIONS.length; i++) {
    if (STATIONS[i].cs === cs) return STATIONS[i].prof;
  }
  return 'handheld';
}

/* Rebuild channels and who-talks-to-whom from the current roster size. */
function rebuildRoster() {
  var n = STATIONS.map(function (s) { return s.cs; });
  CH.COMMAND = n.slice(0, Math.min(6, n.length));
  CH.ADMIN   = n.length > 5 ? [n[0]].concat(n.slice(5)) : n.slice(0, 2);

  PAIRS = [];
  for (var i = 1; i < n.length; i++) PAIRS.push([n[i], n[0]]);       // to base
  for (var j = 1; j + 1 < n.length; j += 2) PAIRS.push([n[j], n[j+1]]); // peer
  if (n.length > 5) PAIRS.push([n[0], n[5]]);
  if (!PAIRS.length && n.length > 1) PAIRS = [[n[1], n[0]]];

  buildChannelTable();
  buildRecorders();
  buildTakeList();
}

function setPeople(count) {
  nPeople = count;
  var keep = {};
  STATIONS.forEach(function (s) { keep[s.cs] = s; });
  STATIONS = ALL_STATIONS.slice(0, count).map(function (base) {
    return keep[base.cs] || JSON.parse(JSON.stringify(base));
  });
  rebuildRoster();
  buildVoices();
  buildPeopleGrid();
  if (autoVoice) castAutomatically();
  buildVoicePanel();
  refreshAll();
}

// ==========================================================================
// THE LOCAL SERVER
// --------------------------------------------------------------------------
// The browser alone can only preview. It cannot clone voices, and it cannot
// write a WAV of synthesised speech — both are hard browser limits.
//
// When server.py is running, the real work happens on your machine instead:
// your own step5_radio_fx.py does the DSP, and Chatterbox does the voice
// cloning. The console then just decides what happens when, and asks the
// server to render it.
//
// Without the server everything still works as a preview. The interface
// says which mode it is in rather than quietly doing less.
// ==========================================================================

var server = { up: false, fx: false, ffmpeg: false, out: '', reason: '' };

function checkServer() {
  server.reason = '';

  /* Opened straight from disk. Relative API calls cannot reach anything, so
     say that rather than claiming the server is down. */
  if (location.protocol === 'file:') {
    server.up = false;
    server.reason = 'file';
    updateServerNote();
    return Promise.resolve(false);
  }

  return fetch('/api/status', { cache: 'no-store' })
    .then(function (r) {
      /* A 404 here means something IS serving on this port, but it is not
         server.py — usually a plain 'python -m http.server' left running.
         It hands out the files perfectly while none of the API exists, which
         looks identical to no server at all. */
      if (r.status === 404) { server.reason = 'other'; throw new Error('wrong server'); }
      if (!r.ok) { server.reason = 'error'; throw new Error('bad response'); }
      return r.json();
    })
    .then(function (st) {
      if (!st || !st.ok) { server.reason = 'error'; throw new Error('bad reply'); }
      server.up     = true;
      server.fx     = !!st.radio_fx;
      server.ffmpeg = !!st.ffmpeg;
      server.out    = st.output_dir || '';
      updateServerNote();
      return true;
    })
    .catch(function () {
      server.up = false;
      if (!server.reason) server.reason = 'none';
      updateServerNote();
      return false;
    });
}

function updateServerNote() {
  $$('.server-note').forEach(function (el) {
    if (server.up) {
      var warn = [];
      if (!server.fx) warn.push('step5_radio_fx.py was not found');
      if (!server.ffmpeg) warn.push('ffmpeg is not installed');

      el.innerHTML = '<span class="ok-t">Connected to your machine.</span> ' +
        'Recording, voice cloning and radio processing all run here, and ' +
        'finished files are written to <span class="mono">' +
        esc(server.out || 'output\\') + '</span>.' +
        (warn.length ? ' <span class="bad">' + esc(warn.join('; ')) + '.</span>' : '');
      el.className = 'note server-note up';
    } else {
      var why;

      if (server.reason === 'file') {
        why = 'This page was opened straight from the file, so it cannot ' +
          'reach the server even if it is running. Open ' +
          '<span class="mono">http://localhost:8000</span> instead.';

      } else if (server.reason === 'other') {
        why = 'Something is answering on this port, but it is not ' +
          '<span class="mono">server.py</span> \u2014 almost certainly a ' +
          '<span class="mono">python -m http.server</span> window left open ' +
          'from earlier. Close that window, then run ' +
          '<span class="mono">python server.py</span> and reload.';

      } else {
        why = 'Start it in your project folder:<br>' +
          '<span class="mono">python server.py</span><br>' +
          'then open <span class="mono">http://localhost:8000</span>. ' +
          'If it says the port is in use, close any other server window first.';
      }

      el.innerHTML = '<span class="bad">Preview only \u2014 no audio files.</span> ' +
        why + '<br><button class="btn sm" data-recheck>Check again</button>';
      el.className = 'note server-note down';

      var btn = el.querySelector('[data-recheck]');
      if (btn) {
        btn.addEventListener('click', function () {
          btn.textContent = '\u2026';
          checkServer().then(function (up) {
            if (!up) {
              var b2 = document.querySelector('.server-note [data-recheck]');
              if (b2) b2.textContent = 'Check again';
            }
          });
        });
      }
    }
  });
}

/* Send a recording to the server so the pipeline can use it. */
function uploadBlob(kind, id, url) {
  if (!server.up) return Promise.resolve(false);
  return fetch(url)
    .then(function (r) { return r.blob(); })
    .then(function (blob) {
      return fetch('/api/upload/' + kind + '/' + id, {
        method: 'POST',
        headers: { 'Content-Type': 'application/octet-stream' },
        body: blob
      });
    })
    .then(function (r) { return r.ok; })
    .catch(function () { return false; });
}

/* Start a job and poll until it finishes. onStep reports progress. */
function runJob(endpoint, payload, onStep, onJobId) {
  return fetch(endpoint, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload)
  })
    .then(function (r) { return r.json(); })
    .then(function (res) {
      if (!res.job) throw new Error(res.error || 'server refused the job');
      if (onJobId) onJobId(res.job);
      return new Promise(function (resolve, reject) {
        var poll = setInterval(function () {
          fetch('/api/job/' + res.job, { cache: 'no-store' })
            .then(function (r) { return r.json(); })
            .then(function (j) {
              if (onStep) onStep(j);
              if (j.state === 'done')  { clearInterval(poll); resolve(j); }
              if (j.state === 'error') { clearInterval(poll); reject(new Error(j.error)); }
            })
            .catch(function () { clearInterval(poll); reject(new Error('lost the server')); });
        }, 700);
      });
    });
}

function stopJob(jid) {
  if (!jid) return Promise.resolve();
  return fetch('/api/job/' + jid + '/cancel', { method: 'POST' }).catch(function () {});
}

// ==========================================================================
// THE RADIOS
// --------------------------------------------------------------------------
// Two SDRs joined by a cable. What the console builds goes through a real
// transmitter and a real receiver — everything except the final radiating
// hop, which needs authority the software cannot supply.
//
// Transmission goes clip by clip rather than as one long file. A ten-minute
// session is several gigabytes of IQ, most of it silence being modulated for
// nothing. Keying between clips is a fraction of the memory and closer to
// how a real net behaves.
// ==========================================================================

var radios = [];
var radiosProblem = '';   // why nothing answered, from the backend, if anything did fail
var lastPlan = null;      // the transmit plan from the most recent build

function checkRadios(force) {
  if (!server.up) {
    radios = [];
    radiosProblem = '';
    drawRadios();
    return Promise.resolve([]);
  }
  return fetch('/api/radios' + (force ? '?refresh=1' : ''), { cache: 'no-store' })
    .then(function (r) { return r.json(); })
    .then(function (j) {
      radios = (j && j.radios) || [];
      radiosProblem = (j && j.problem) || '';
      drawRadios();
      return radios;
    })
    .catch(function () { radios = []; radiosProblem = ''; drawRadios(); return []; });
}

function onlineCount() {
  return radios.filter(function (r) { return r.online; }).length;
}

function drawRadios() {
  var host = $('#sdr-grid');
  var n = radios.length;

  if (host) {
    if (!server.up) {
      host.innerHTML = '<p class="empty">The server is not running, so the ' +
        'radios cannot be checked. Start it with ' +
        '<span class="mono">python server.py</span>.</p>';
    } else if (!n) {
      host.innerHTML = '<p class="empty">No radios responded.' +
        (radiosProblem
          ? ' <span class="mono" style="font-size:11px">' + esc(radiosProblem) + '</span>'
          : ' Check they are plugged in and the Ready light is on.') +
        '</p>';
    } else {
      host.innerHTML = '';
      radios.forEach(function (r) {
        var d = document.createElement('div');
        d.className = 'sdr on';
        d.innerHTML =
          '<div class="sdr-h">' +
            '<span class="sdr-n">' + esc(r.label || ('Radio ' + r.n)) + '</span>' +
            '<span class="sdr-dot"></span>' +
          '</div>' +
          '<div class="sdr-s">Connected</div>' +
          '<div class="sdr-u mono">' + esc(r.uri) + '</div>' +
          '<div class="sdr-d">' + esc(r.detail || '') +
            (r.serial ? '  &middot; ' + esc(r.serial) : '') + '</div>' +
          (r.also && r.also.length
            ? '<div class="sdr-d">also at ' + esc(r.also.join(', ')) + '</div>'
            : '');
        host.appendChild(d);
      });
    }
  }

  var m = $('#m-radios');
  if (m) {
    m.textContent = !server.up ? 'server not running'
      : !n ? 'none found'
      : n + (n === 1 ? ' radio' : ' radios') + ' connected';
  }

  var msg = $('#sdr-msg');
  if (msg) {
    if (!server.up) {
      msg.textContent = '';
    } else if (n === 0) {
      msg.innerHTML = '<span class="bad">No radios answered.</span> ' +
        (radiosProblem
          ? esc(radiosProblem)
          : 'Check the USB connection and that pyadi-iio is installed.');
    } else if (n === 1) {
      msg.innerHTML = '<span class="ok-t">One radio connected.</span> ' +
        'It can transmit and receive on itself with a cable between its two ' +
        'ports. A second board needs its own subnet — see the README.';
    } else {
      msg.innerHTML = '<span class="ok-t">' + n + ' radios connected.</span>';
    }
  }

  drawAssign();
  drawMixPicker();
  drawReceived();

  var go = $('#tx-go');
  if (go) {
    go.disabled = !(server.up && n > 0 && lastPlan);
    var note = $('#tx-note');
    if (note && !go.disabled) {
      note.innerHTML = 'Ready to send ' + lastPlan.transmissions.length +
        ' transmissions.';
    } else if (note) {
      note.innerHTML = !server.up ? ''
        : n === 0 ? 'No radio to send to.'
        : 'Build a session first, then come back here.';
    }
  }
}

/* ---- Which radio transmits, which receives ---------------------------- */

function radioOptions(selectedUri) {
  return radios.map(function (r) {
    return '<option value="' + esc(r.uri) + '"' +
      (r.uri === selectedUri ? ' selected' : '') + '>' +
      esc(r.label || ('Radio ' + r.n)) + '  \u2014  ' + esc(r.uri) +
      '</option>';
  }).join('');
}

function drawAssign() {
  var tx = $('#tx-radio'), rx = $('#rx-radio');
  if (!tx || !rx) return;

  if (!radios.length) {
    tx.innerHTML = rx.innerHTML = '<option value="">no radios</option>';
    tx.disabled = rx.disabled = true;
    updateLinkLabel();
    return;
  }

  tx.disabled = rx.disabled = false;

  /* Keep whatever was already chosen if that radio is still present,
     otherwise pick sensible defaults: the first board transmits, and the
     second receives if there is one. */
  var prevTx = tx.value, prevRx = rx.value;
  var uris = radios.map(function (r) { return r.uri; });

  var txSel = uris.indexOf(prevTx) >= 0 ? prevTx : uris[0];
  var rxSel = uris.indexOf(prevRx) >= 0 ? prevRx
            : (uris.length > 1 ? uris[1] : uris[0]);

  tx.innerHTML = radioOptions(txSel);
  rx.innerHTML = radioOptions(rxSel);

  updateLinkLabel();
}

function updateLinkLabel() {
  var tx = $('#tx-radio'), rx = $('#rx-radio');
  var label = $('#ls-label'), note = $('#rx-note');
  if (!tx || !rx) return;

  var same = tx.value && tx.value === rx.value;

  if (label) {
    label.innerHTML = !tx.value ? '&mdash;'
      : same ? 'loopback' : 'over the link';
    label.className = 'ls-al' + (same ? ' loop' : '');
  }

  if (note) {
    if (!tx.value) {
      note.innerHTML = '&mdash;';
    } else if (same) {
      note.innerHTML = 'The same board transmits and receives. Connect a ' +
        'cable between its own TX and RX ports. Everything except the hop ' +
        'between separate radios is still exercised.';
    } else {
      note.innerHTML = 'Two separate boards. Wire the transmitter\u2019s TX ' +
        'to the receiver\u2019s RX through an attenuator, or use antennas a ' +
        'metre apart at low gain.';
    }
  }

  var go = $('#mix-go');
  if (go) {
    var f = $('#mix-file');
    go.disabled = !(server.up && radios.length && f && f.value &&
                    !f.dataset.tooBig);
  }
}

/* ---- Sending a chosen file to a chosen radio -------------------------- */

var outFiles = [];

function loadOutputFiles() {
  if (!server.up) { outFiles = []; drawMixPicker(); return Promise.resolve(); }
  return fetch('/api/output-files', { cache: 'no-store' })
    .then(function (r) { return r.json(); })
    .then(function (j) {
      outFiles = (j && j.files) || [];
      drawMixPicker();
      drawReceived();
    })
    .catch(function () {
      outFiles = [];
      drawMixPicker();
      drawReceived();
    });
}

/* ---- Sending the whole mixed session ---------------------------------- */

function drawMixPicker() {
  var sel = $('#mix-file');
  if (!sel) return;

  /* Mixed sessions first — that is what this control is for — but list
     everything, because sometimes one side alone is what you want. */
  var mixed = outFiles.filter(function (f) {
    return f.name.indexOf('session_mixed') === 0;
  });
  var rest = outFiles.filter(function (f) {
    return f.name.indexOf('session_mixed') !== 0 &&
           f.name.indexOf('received_') !== 0;
  });
  var ordered = mixed.concat(rest);

  if (!ordered.length) {
    sel.innerHTML = '<option value="">nothing in your output folder</option>';
    $('#mix-note').textContent = 'Build a session first on either make screen.';
    var g = $('#mix-go');
    if (g) g.disabled = true;
    return;
  }

  var prev = sel.value;
  var names = ordered.map(function (f) { return f.name; });

  /* Default to the first file under the sanity cap the server itself
     enforces (see CHUNK_SECONDS / the 3600s cap in transmit_file()) —
     everything else is now sent in bounded chunks regardless of length,
     so there's nothing left to "fit in memory" for. */
  function fits(f) {
    return f.seconds <= 3600;
  }
  var sendable = ordered.filter(fits)[0];
  var keep = names.indexOf(prev) >= 0 ? prev
           : (sendable ? sendable.name : names[0]);

  sel.innerHTML = ordered.map(function (f) {
    return '<option value="' + esc(f.name) + '"' +
      (f.name === keep ? ' selected' : '') + '>' + esc(f.name) +
      '  (' + f.seconds + 's, ' + f.mb + ' MB)</option>';
  }).join('');

  mixNote();
}

/* Sent in bounded chunks now regardless of length (see transmit_file() in
   server.py), so this is purely informational — a heads-up on how long a
   long file will actually take, not a limit that blocks sending. */
function mixNote() {
  var sel = $('#mix-file'), note = $('#mix-note');
  if (!sel || !note) return;

  var f = outFiles.filter(function (x) { return x.name === sel.value; })[0];
  if (!f) { note.textContent = ''; return; }

  if (f.seconds > 3600) {
    sel.dataset.tooBig = '1';
    note.innerHTML = '<span class="bad">' + (f.seconds / 60).toFixed(0) +
      ' minutes is a lot to send as one file \u2014 double check this is ' +
      'the one you meant.</span> The clip-by-clip option handles any ' +
      'length too.';
  } else {
    delete sel.dataset.tooBig;
    var gib = f.seconds * 1e6 * 8 / (1024 * 1024 * 1024);
    note.innerHTML = f.seconds + ' seconds \u2014 sent in 20s chunks, about ' +
      gib.toFixed(2) + ' GiB of radio samples total. Transmission takes ' +
      'about as long as the file itself.';
  }

  updateLinkLabel();
}

/* ---- Link measurement — what actually came off the receiver -----------
   Rendered numerically (rf_level, sent/received duration, peak levels,
   a correlation "match" score, and a plain-language verdict) because
   listening by ear is not always possible or reliable. Built to match
   the .measure / .mz-* rules in style.css. */

function showMeasurementIn(selector, m, name) {
  var host = $(selector);
  if (!host || !m) return;

  var verdict = m.verdict || '';
  var noSignal = /^NO SIGNAL/.test(verdict);
  var overload = /^OVERLOAD/.test(verdict);
  var good = /^LINK GOOD/.test(verdict);

  function stat(label, value, warn) {
    return '<div class="mz' + (warn ? ' warn' : good ? ' good' : '') + '">' +
      '<div class="mz-n">' + esc(value) + '</div>' +
      '<div class="mz-k">' + esc(label) + '</div>' +
      '</div>';
  }

  host.innerHTML =
    '<div class="mz-v' + (good ? ' good' : (noSignal || overload) ? ' bad' : '') +
      '">' + esc(verdict || 'Measured') + '</div>' +
    '<div class="mz-f">' + esc(name || '') + '</div>' +
    '<div class="mz-grid">' +
      stat('RF level', m.rf_level, noSignal || overload) +
      stat('Sent (s)', m.sent_seconds) +
      stat('Received (s)', m.received_seconds,
           Math.abs((m.sent_seconds || 0) - (m.received_seconds || 0)) > 1) +
      stat('Sent peak', m.sent_peak) +
      stat('Received peak', m.received_peak) +
      stat('Match', m.match, (m.match || 0) < 0.3) +
    '</div>';

  host.style.display = 'block';
}

var currentMixJob = null;   // job id for the send-and-receive flow, so Stop can target it

function sendMixed() {
  var go = $('#mix-go'), stop = $('#mix-stop');
  var result = $('#mix-result');
  var name = $('#mix-file').value;
  var txUri = $('#tx-radio').value;
  var rxUri = $('#rx-radio').value;

  if (!name || !txUri) return;

  var carrier = parseFloat($('#tx-carrier').value) || 488;
  var gain = parseFloat($('#tx-gain').value);
  var rxGain = parseFloat($('#rx-gain').value);
  var loopback = txUri === rxUri;
  var repeat = $('#mix-repeat') ? $('#mix-repeat').checked : false;
  var repeatPause = parseFloat($('#mix-repeat-pause').value);

  go.disabled = true;
  var label = go.textContent;
  go.textContent = 'Sending\u2026';
  if (stop) stop.disabled = false;
  $('#mix-measure').style.display = 'none';
  $('#mix-players').style.display = 'none';

  var txName = radioName(txUri), rxName = radioName(rxUri);
  result.innerHTML = 'Opening ' + esc(txName) +
    (loopback ? '' : ' and ' + esc(rxName)) + '\u2026';

  runJob('/api/transmit-file', {
    file: name,
    tx_uri: txUri,
    rx_uri: rxUri,
    loopback: loopback,
    gain: isNaN(gain) ? null : gain,
    rx_gain: isNaN(rxGain) ? null : rxGain,
    carrier_mhz: carrier,
    repeat: repeat,
    repeat_pause: isNaN(repeatPause) ? 1 : repeatPause
  }, function (j) {
    var passInfo = (j.measured && j.measured.passes)
      ? ' \u2014 pass ' + j.measured.passes : '';
    result.innerHTML = '<b>' + esc(txName) + ' transmitting.</b> ' +
      esc(j.step || '') + passInfo;

    // Live-update the measurement panel between passes too, not just at
    // the very end, since a repeat run may never reach "done" until Stop
    // is pressed.
    if (j.measured) showMeasurementIn('#mix-measure', j.measured, name);

    var received = (j.files || [])[0];
    if (received) {
      $('#mix-players').style.display = 'grid';
      $('#mix-sent').src = '/api/download/' + encodeURIComponent(name);
      $('#mix-recv').src = '/api/download/' + encodeURIComponent(received) +
        '?t=' + Date.now();   // bust the cache — repeat overwrites this file in place
    }
  }, function (jid) { currentMixJob = jid; })
    .then(function (j) {
      go.disabled = false;
      go.textContent = label;
      if (stop) stop.disabled = true;

      var received = (j.files || [])[0];
      result.innerHTML = '<span class="ok-t">Done.</span> ' +
        esc(txName) + ' \u2192 ' + esc(rxName) + ' at ' + carrier + ' MHz. ' +
        esc(j.step || '') +
        (received
          ? '<br>Recorded as <span class="mono">' + esc(received) + '</span>'
          : '<br><span class="bad">Nothing was recorded — check the ' +
            'receiving radio.</span>');

      if (j.measured) showMeasurementIn('#mix-measure', j.measured, name);

      if (received) {
        $('#mix-players').style.display = 'grid';
        $('#mix-sent').src = '/api/download/' + encodeURIComponent(name);
        $('#mix-recv').src = '/api/download/' + encodeURIComponent(received) +
          '?t=' + Date.now();
      }

      loadOutputFiles();      // the new recording joins the list
    })
    .catch(function (err) {
      go.disabled = false;
      go.textContent = label;
      if (stop) stop.disabled = true;
      result.innerHTML = '<span class="bad">' + esc(err.message) + '</span>';
    });
}

function radioName(uri) {
  var r = radios.filter(function (x) { return x.uri === uri; })[0];
  return r ? (r.label || ('Radio ' + r.n)) : uri;
}

/* ---- Everything recorded off a receiver ------------------------------- */

function drawReceived() {
  var host = $('#recv-list');
  if (!host) return;

  var recs = outFiles.filter(function (f) {
    return f.name.indexOf('received_') === 0;
  });

  if (!recs.length) {
    host.innerHTML = '<p class="empty">Nothing recorded yet. Transmit ' +
      'something and it will appear here.</p>';
    return;
  }

  host.innerHTML = '';
  recs.forEach(function (f) {
    var row = document.createElement('div');
    row.className = 'recv-row';
    row.innerHTML =
      '<div class="recv-n mono">' + esc(f.name) + '</div>' +
      '<div class="recv-m mono">' + f.seconds + 's &middot; ' + f.mb + ' MB</div>' +
      '<audio controls src="/api/download/' + encodeURIComponent(f.name) +
        '"></audio>' +
      '<a class="btn sm" href="/api/download/' + encodeURIComponent(f.name) +
        '" download>Save</a>';
    host.appendChild(row);
  });
}

var currentSessionJob = null;   // job id for the clip-by-clip send, so Stop can target it

function transmitSession() {
  var go = $('#tx-go'), note = $('#tx-note');
  if (!lastPlan) return;

  var rxWanted = $('#tx-listen').value === 'yes';
  var rx = radios.filter(function (r) { return r.online; });

  /* With two boards, receive on the second one. With exactly one, receive
     on itself — a cable from its own TX port to its own RX port (through
     the attenuator) is a legitimate loopback link and exercises everything
     except the hop between two separate boards. Only skip the receiver
     entirely if nothing is connected at all. */
  var txPick = rx.length ? rx[0].uri : null;
  var rxPick = !rxWanted || !rx.length ? null
    : rx.length > 1 ? rx[1].uri
    : txPick;   // one board — loop back to itself

  var payload = {
    tx_uri: txPick,
    rx_uri: rxPick,
    carrier_mhz: parseFloat($('#tx-carrier').value) || 2400,
    max_gap_s: parseFloat($('#tx-gap').value) || 4,
    transmissions: lastPlan.transmissions
  };

  go.disabled = true;
  $('#tx-stop').disabled = false;
  note.innerHTML = 'Opening the transmitter&hellip;';

  runJob('/api/transmit', payload, function (j) {
    var pct = j.total ? Math.round(j.done / j.total * 100) : 0;
    note.innerHTML = '<b>On air.</b> ' + esc(j.step || '') +
      ' \u2014 ' + j.done + ' of ' + j.total + ' (' + pct + '%)';
  }, function (jid) { currentSessionJob = jid; })
    .then(function (j) {
      var extra = '';
      if (j.files && j.files.length) {
        extra = '<br>Files saved: ' + j.files.map(function (f) {
          return '<a href="/api/download/' + encodeURIComponent(f) +
                 '" download>' + esc(f) + '</a>';
        }).join(', ');
      }
      if (j.error) {
        extra += '<br><span class="bad">' + esc(j.error) + '</span>';
      }
      note.innerHTML = '<span class="ok-t">Finished.</span> ' +
        esc(j.step || '') + extra;
      go.disabled = false;
      $('#tx-stop').disabled = true;
    })
    .catch(function (err) {
      note.innerHTML = '<span class="bad">' + esc(err.message) + '</span>';
      go.disabled = false;
      $('#tx-stop').disabled = true;
    });
}

// ==========================================================================
// SAVED DATA
// --------------------------------------------------------------------------
// Everything you record and set up is kept in the browser's own database, so
// closing the tab or reloading does not lose it.
//
// IndexedDB rather than simpler storage, because recordings are audio blobs:
// they are binary and can run to tens of megabytes, which the small key-value
// stores cannot hold.
//
// It stays on this machine. Nothing is uploaded.
// ==========================================================================

var DB_NAME = 'netcontrol';
var DB_VER  = 1;
var db      = null;
var saveTimer = null;

function openDb() {
  return new Promise(function (resolve) {
    if (!window.indexedDB) { resolve(null); return; }
    var req = indexedDB.open(DB_NAME, DB_VER);
    req.onupgradeneeded = function (e) {
      var d = e.target.result;
      if (!d.objectStoreNames.contains('state')) d.createObjectStore('state');
      if (!d.objectStoreNames.contains('audio')) d.createObjectStore('audio');
    };
    req.onsuccess = function () { db = req.result; resolve(db); };
    req.onerror   = function () { resolve(null); };
  });
}

function dbPut(store, key, val) {
  return new Promise(function (resolve) {
    if (!db) { resolve(false); return; }
    try {
      var tx = db.transaction(store, 'readwrite');
      tx.objectStore(store).put(val, key);
      tx.oncomplete = function () { resolve(true); };
      tx.onerror    = function () { resolve(false); };
    } catch (e) { resolve(false); }
  });
}

function dbGet(store, key) {
  return new Promise(function (resolve) {
    if (!db) { resolve(null); return; }
    try {
      var tx = db.transaction(store, 'readonly');
      var r  = tx.objectStore(store).get(key);
      r.onsuccess = function () { resolve(r.result); };
      r.onerror   = function () { resolve(null); };
    } catch (e) { resolve(null); }
  });
}

function dbClear() {
  return new Promise(function (resolve) {
    if (!db) { resolve(); return; }
    try {
      var tx = db.transaction(['state', 'audio'], 'readwrite');
      tx.objectStore('state').clear();
      tx.objectStore('audio').clear();
      tx.oncomplete = function () { resolve(); };
      tx.onerror    = function () { resolve(); };
    } catch (e) { resolve(); }
  });
}

/* Blob URLs cannot be stored, so audio is kept as the blob itself and a
   fresh URL is made when it is loaded back. */
function urlToBlob(url) {
  return fetch(url).then(function (r) { return r.blob(); });
}

/* Debounced, because this fires on every keystroke in a name field. */
function saveState() {
  clearTimeout(saveTimer);
  saveTimer = setTimeout(doSave, 400);
}

function doSave() {
  if (!db) return;

  var settings = {
    nPeople: nPeople,
    topicsOn: topicsOn,
    on: on,
    preset: preset.id,
    minutes: minutes,
    autoVoice: autoVoice,
    assign: assign,
    stations: STATIONS.map(function (st) {
      return { cs:st.cs, role:st.role, prof:st.prof, speaker:st.speaker };
    }),
    recordings: library.map(function (L) {
      return { id:L.id, name:L.name, topic:L.topic, prof:L.prof, secs:L.secs };
    }),
    voices: voices.map(function (v) {
      return { id:v.id, name:v.name, secs:v.secs };
    }),
    savedAt: Date.now()
  };

  dbPut('state', 'settings', settings);

  /* The server copy is the one that matters. It lives in the project folder,
     so it survives a different port, a cleared cache, or another browser —
     all of which lose the browser's own database. */
  if (server.up) {
    fetch('/api/state', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(settings)
    }).catch(function () {});
  }

  /* Audio blobs, one key each. Only written when new. */
  library.concat(voices).forEach(function (item) {
    if (item._stored) return;
    urlToBlob(item.url).then(function (blob) {
      return dbPut('audio', item.id, blob);
    }).then(function (okv) { if (okv) item._stored = true; });
  });

  updateSavedNote();
}

function loadState() {
  /* Ask the server first. Its copy is authoritative because it does not
     depend on the address the page was opened from. */
  var fromServer = server.up
    ? fetch('/api/state', { cache: 'no-store' })
        .then(function (r) { return r.json(); })
        .then(function (j) { return (j && j.ok) ? j.state : null; })
        .catch(function () { return null; })
    : Promise.resolve(null);

  return fromServer.then(function (srvState) {
    if (srvState) return applyState(srvState, true);
    return dbGet('state', 'settings').then(function (st) {
      return st ? applyState(st, false) : false;
    });
  });
}

function applyState(st, viaServer) {
  return Promise.resolve().then(function () {
    if (!st) return false;

    nPeople   = st.nPeople || nPeople;
    minutes   = st.minutes || minutes;
    autoVoice = st.autoVoice !== false;
    if (st.topicsOn) topicsOn = st.topicsOn;
    if (st.on) on = st.on;
    if (st.preset) {
      PRESETS.forEach(function (p) { if (p.id === st.preset) preset = p; });
    }
    if (st.stations && st.stations.length) {
      STATIONS = st.stations.map(function (x) {
        return { cs:x.cs, role:x.role, prof:x.prof, speaker:x.speaker || '' };
      });
    }

    var jobs = [];

    /* Audio comes back from wherever the settings did, so the two never
       fall out of step. */
    function fetchAudio(kind, id) {
      if (viaServer) {
        return fetch('/api/audio/' + kind + '/' + id, { cache: 'no-store' })
          .then(function (r) { return r.ok ? r.blob() : null; })
          .catch(function () { return null; });
      }
      return dbGet('audio', id);
    }

    (st.voices || []).forEach(function (v) {
      jobs.push(fetchAudio('voice', v.id).then(function (blob) {
        if (!blob) return;
        voices.push({ id:v.id, name:v.name, secs:v.secs,
                      url:URL.createObjectURL(blob), _stored:true });
      }));
    });

    (st.recordings || []).forEach(function (L) {
      jobs.push(fetchAudio('recording', L.id).then(function (blob) {
        if (!blob) return;
        library.push({ id:L.id, name:L.name, topic:L.topic,
                       prof:L.prof || 'handheld', secs:L.secs,
                       url:URL.createObjectURL(blob), _stored:true });
      }));
    });

    return Promise.all(jobs).then(function () {
      if (st.assign) assign = st.assign;
      syncRefs();
      return true;
    });
  });
}

function updateSavedNote() {
  var el = $('#saved-note');
  if (!el) return;
  var n = library.length, v = voices.length;
  if (!n && !v) {
    el.textContent = 'Nothing saved yet. Anything you record is kept ' +
      'automatically and will still be here next time.';
    return;
  }
  el.innerHTML = '<span class="ok-t">Saved:</span> ' +
    n + (n === 1 ? ' recording' : ' recordings') + ', ' +
    v + (v === 1 ? ' voice' : ' voices') + '. ' +
    (server.up
      ? 'Kept in your project folder, so they survive closing the tab, ' +
        'reloading, or a different port.'
      : 'Kept in this browser only. Start the server to keep them in your ' +
        'project folder instead.');
}

// ==========================================================================
// NAVIGATION
// ==========================================================================

var VIEWS = {
  home:     'Radio traffic simulator',
  record:   'Record the messages',
  compose:  'Written by the computer',
  play:     'Listening',
  stations: 'Stations on the net',
  settings: 'Session settings',
  radios:   'Radios',
  export:   'Save and export'
};

var navStack = [];

function go(name, opts, isBack) {
  stopPlayback();

  var current = document.querySelector('.view.on');
  var currentName = current ? current.id.replace('v-', '') : null;

  /* Remember where we came from, so Back returns there rather than
     always dumping the user at the main menu. */
  if (!isBack && currentName && currentName !== name) {
    navStack.push({ name: currentName, opts: lastOpts });
    if (navStack.length > 12) navStack.shift();
  }
  if (name === 'home') navStack = [];
  lastOpts = opts || {};

  $$('.view').forEach(function (v) { v.classList.remove('on'); });
  var v = $('#v-' + name);
  if (v) v.classList.add('on');

  $('#mast-sub').textContent = VIEWS[name] || '';
  $('#home-btn').style.visibility = (name === 'home') ? 'hidden' : 'visible';

  if (name === 'play') openPlayer(opts && opts.src);
  if (name === 'radios') { checkRadios(true); loadOutputFiles(); }
  if (name === 'home') refreshMenu();
  updateBackButton();
  window.scrollTo(0, 0);
}

var lastOpts = {};

function goBack() {
  var prev = navStack.pop();
  if (prev) go(prev.name, prev.opts, true);
  else go('home', null, true);
}

/* The button label tells you where it goes, so Back is never a surprise. */
function updateBackButton() {
  var btn = $('#home-btn');
  if (!btn) return;
  var on = document.querySelector('.view.on');
  var here = on ? on.id.replace('v-', '') : 'home';

  if (here === 'home') { btn.style.visibility = 'hidden'; return; }
  btn.style.visibility = 'visible';

  var prev = navStack.length ? navStack[navStack.length - 1].name : 'home';
  btn.title = 'Back to ' + (VIEWS[prev] || 'the main menu');
}

// ==========================================================================
// PEOPLE AND TOPICS  (shared by the record and compose screens)
// ==========================================================================

function buildPeople(hostId, hintId) {
  var host = $('#' + hostId);
  host.innerHTML = '';
  PEOPLE.forEach(function (P) {
    var b = document.createElement('button');
    b.type = 'button';
    b.className = 'pill';
    b.dataset.on = (P.n === nPeople) ? '1' : '0';
    b.innerHTML = P.label + '<span class="pn">' + P.note + '</span>';
    b.addEventListener('click', function () {
      setPeople(P.n);
      buildPeople('rec-people', 'rec-people-h');
      buildPeople('gen-people', 'gen-people-h');
    });
    host.appendChild(b);
  });

  var hint = $('#' + hintId);
  if (hint) {
    hint.innerHTML = 'On the net: <span class="mono">' +
      STATIONS.map(function (s) { return esc(s.cs); }).join('  ') + '</span>';
  }
}

function buildTopics(hostId) {
  var host = $('#' + hostId);
  host.innerHTML = '';
  TOPICS.forEach(function (T) {
    var b = document.createElement('button');
    b.type = 'button';
    b.className = 'topic';
    b.dataset.id = T.id;
    b.dataset.on = topicsOn[T.id] ? '1' : '0';
    b.innerHTML =
      '<span class="tp-n">' + esc(T.name) + '</span>' +
      '<span class="tp-b">' + esc(T.note) + '</span>';
    b.addEventListener('click', function () {
      topicsOn[T.id] = !topicsOn[T.id];
      applyTopics();
      buildTopics('rec-topics');
      buildTopics('gen-topics');
      refreshAll();
    });
    host.appendChild(b);
  });
}

/* Topics drive the underlying situation list. */
function applyTopics() {
  Object.keys(on).forEach(function (k) { on[k] = false; });
  TOPICS.forEach(function (T) {
    if (topicsOn[T.id]) T.items.forEach(function (id) { on[id] = true; });
  });
  $$('.chip').forEach(function (b) {
    b.dataset.on = on[b.dataset.id] ? '1' : '0';
  });
}

// ==========================================================================
// COMPOSE  (computer-written messages)
// ==========================================================================

function buildPresets() {
  var host = $('#presets');
  host.innerHTML = '';
  PRESETS.forEach(function (ps) {
    var b = document.createElement('button');
    b.type = 'button';
    b.className = 'card';
    b.dataset.on = (ps.id === preset.id) ? '1' : '0';
    b.innerHTML =
      '<div class="card-n">' + esc(ps.name) + '</div>' +
      '<div class="card-b">' + esc(ps.blurb) + '</div>' +
      '<div class="card-m">' + busyWord(ps.occ) + ' &middot; ' +
        (ps.incident === 0 ? 'nothing happens' : ps.incident + '% incidents') + '</div>';
    b.addEventListener('click', function () {
      preset = ps;
      $$('#presets .card').forEach(function (c, i) {
        c.dataset.on = (PRESETS[i].id === ps.id) ? '1' : '0';
      });
      compose();
      refreshAll();
      saveState();
    });
    host.appendChild(b);
  });
}

function buildLengths() {
  var host = $('#lengths');
  host.innerHTML = '';
  LENGTHS.forEach(function (L) {
    var b = document.createElement('button');
    b.type = 'button';
    b.className = 'pill';
    b.dataset.on = (L.m === minutes) ? '1' : '0';
    b.innerHTML = L.label + '<span class="pn">' + L.note + '</span>';
    b.addEventListener('click', function () {
      minutes = L.m;
      $$('#lengths .pill').forEach(function (p, i) {
        p.dataset.on = (LENGTHS[i].m === minutes) ? '1' : '0';
      });
      compose();
      refreshAll();
    });
    host.appendChild(b);
  });
}

function buildCats() {
  var host = $('#cats');
  host.innerHTML = '';
  CATS.forEach(function (cat) {
    var wrap = document.createElement('div');
    wrap.className = 'catrow';
    wrap.innerHTML = '<div class="cat">' + esc(cat.name) + '</div>';
    var row = document.createElement('div');
    row.className = 'chips';
    cat.items.forEach(function (it) {
      var b = document.createElement('button');
      b.type = 'button';
      b.className = 'chip';
      b.dataset.id = it[0];
      b.dataset.on = on[it[0]] ? '1' : '0';
      b.innerHTML = esc(it[1]) + '<span class="ct">' + it[2] + '</span>';
      b.addEventListener('click', function () {
        on[it[0]] = !on[it[0]];
        b.dataset.on = on[it[0]] ? '1' : '0';
        refreshAll();
      });
      row.appendChild(b);
    });
    wrap.appendChild(row);
    host.appendChild(wrap);
  });
}

function setAll(fn) {
  $$('.chip').forEach(function (b) {
    var v = fn(b.dataset.id);
    on[b.dataset.id] = v;
    b.dataset.on = v ? '1' : '0';
  });
  refreshAll();
}

// ==========================================================================
// LOADING YOUR OWN EXCHANGES
// --------------------------------------------------------------------------
// The built-in templates exist only so the interface has something to show
// before your machine has produced anything. Once exchanges_curated.json is
// loaded, everything is drawn from it — same words your Python pipeline will
// speak, so the preview stops being a rough approximation.
// ==========================================================================

function loadPool(text, filename) {
  var data;
  try {
    data = JSON.parse(text);
  } catch (e) {
    return { error: 'That file is not valid JSON.' };
  }

  if (!Array.isArray(data)) {
    return { error: 'Expected a list of exchanges. This looks like a ' +
      'different kind of file.' };
  }

  var good = [], skipped = 0;
  data.forEach(function (ex) {
    var tx = ex && ex.transmissions;
    if (!Array.isArray(tx) || !tx.length) { skipped++; return; }

    var lines = [];
    for (var i = 0; i < tx.length; i++) {
      var t = tx[i];
      if (!t || !t.callsign || !t.text) { lines = null; break; }
      lines.push({ cs: String(t.callsign).trim().toUpperCase(),
                   text: String(t.text).trim() });
    }
    if (!lines) { skipped++; return; }

    good.push({
      scenario: ex.scenario || 'unknown',
      units: (ex.units || []).map(function (u) { return String(u).toUpperCase(); }),
      thread_id: ex.thread_id || null,
      lines: lines
    });
  });

  if (!good.length) {
    return { error: 'No usable exchanges found in that file.' };
  }

  pool = good;
  poolName = filename;
  return { count: good.length, skipped: skipped };
}

/* Which callsigns appear in the loaded pool, so we can tell the user when
   their roster does not match the file. */
function poolCallsigns() {
  var seen = {};
  (pool || []).forEach(function (ex) {
    ex.lines.forEach(function (L) { seen[L.cs] = true; });
  });
  return Object.keys(seen).sort();
}

function poolScenarios() {
  var seen = {};
  (pool || []).forEach(function (ex) { seen[ex.scenario] = (seen[ex.scenario]||0) + 1; });
  return seen;
}

function updateLoadPanel(msg, bad) {
  var n = $('#load-name'), b = $('#load-note'), clear = $('#load-clear');
  if (!n) return;

  if (msg) {
    n.textContent = bad ? 'Could not load that file' : poolName;
    b.innerHTML = bad ? '<span class="bad">' + esc(msg) + '</span>' : msg;
    n.className = 'load-n' + (bad ? '' : ' ok');
    if (clear) clear.hidden = !pool;
    return;
  }

  if (!pool) {
    n.textContent = 'Using built-in examples';
    n.className = 'load-n';
    b.textContent = 'A small set of sample exchanges, enough to show the ' +
      'timing. Load your own file to use the real ones.';
    if (clear) clear.hidden = true;
    return;
  }

  var cs = poolCallsigns();
  var mine = STATIONS.map(function (s) { return s.cs; });
  var unknown = cs.filter(function (c) { return mine.indexOf(c) < 0; });
  var scen = Object.keys(poolScenarios()).length;

  n.textContent = poolName;
  n.className = 'load-n ok';
  b.innerHTML = pool.length + ' exchanges \u00b7 ' + scen +
    ' situations \u00b7 ' + cs.length + ' stations' +
    (unknown.length
      ? '<br><span class="bad">' + unknown.length + ' station' +
        (unknown.length === 1 ? '' : 's') + ' in the file are not on your net (' +
        esc(unknown.slice(0, 4).join(', ')) +
        (unknown.length > 4 ? '\u2026' : '') + '). Those exchanges will be ' +
        'skipped &mdash; add the stations, or use a matching file.</span>'
      : '');
  if (clear) clear.hidden = false;
}

// ==========================================================================
// THE SHUFFLE BAG
// --------------------------------------------------------------------------
// Picking exchanges at random sounds fair but repeats far sooner than anyone
// expects — it is the birthday problem. With 350 exchanges the first repeat
// arrives after roughly 24 draws, about 20 minutes of session. Multiplying
// the pool barely helps: 2000 exchanges only pushes it to 48 minutes.
//
// Dealing from a shuffled bag instead means nothing repeats until the whole
// pool is spent. The same 350 exchanges then run for nearly five hours.
//
// This is by far the cheapest realism improvement available: no extra
// content, no extra recording, just a different way of choosing.
// ==========================================================================

function makeBag(items, R) {
  var order = items.slice();
  for (var i = order.length - 1; i > 0; i--) {          // Fisher-Yates
    var j = Math.floor(R() * (i + 1));
    var t = order[i]; order[i] = order[j]; order[j] = t;
  }
  return {
    order: order,
    at: 0,
    /* Take the next item that passes `ok`. Reshuffles when spent, so a long
       session keeps running rather than falling silent. */
    take: function (ok) {
      var tried = 0, n = this.order.length;
      while (tried < n) {
        if (this.at >= n) {                              // refill
          for (var i = n - 1; i > 0; i--) {
            var j = Math.floor(R() * (i + 1));
            var t = this.order[i]; this.order[i] = this.order[j]; this.order[j] = t;
          }
          this.at = 0;
        }
        var item = this.order[this.at++];
        tried++;
        if (!ok || ok(item)) return item;
      }
      return null;
    }
  };
}

// ==========================================================================
// SCHEDULING
// Shared by both sources. Produces a timed list of transmissions with
// realistic gaps — the silence matters as much as the traffic.
// ==========================================================================

function channelFor(a, b) {
  if (CH.ADMIN.indexOf(a) < 0 || CH.ADMIN.indexOf(b) < 0) return 'COMMAND';
  var only = CH.ADMIN.filter(function (c) { return CH.COMMAND.indexOf(c) < 0; });
  return (only.indexOf(a) >= 0 || only.indexOf(b) >= 0) ? 'ADMIN' : 'COMMAND';
}

function schedule(src, R) {
  var situations = chosen();
  if (!situations.length || !PAIRS.length) return null;

  var mine = STATIONS.map(function (s) { return s.cs; });

  /* One bag per content source. Dealing from a shuffled bag rather than
     picking at random is what stops the same exchange coming round every
     twenty minutes. */
  var poolBag = null, recBag = null;
  if (src === 'recorded') {
    recBag = makeBag(library, R);
  } else if (pool) {
    var usablePool = pool.filter(function (p) {
      return p.lines.every(function (L) { return mine.indexOf(L.cs) >= 0; });
    });
    if (!usablePool.length) return { tx: [], dur: minutes * 60, air: 0, src: src };
    poolBag = makeBag(usablePool, R);
  }
  var pairBag = makeBag(PAIRS, R);

  var dur = minutes * 60;
  var occ = preset.occ / 100;
  var dbl = preset.dbl / 100;
  var thr = preset.thread / 100;
  var exm = $('#exm') ? $('#exm').value : 'both';

  var tx = [], air = 0, guard = 0;
  var t = 4 + R() * 25;
  var busy = R() < 0.5, run = 2 + Math.floor(R() * 3);

  while (t < dur - 12 && guard++ < 1500) {
    if (air / Math.max(t, 1) > occ * 1.25) { t += 45 + R() * 130; continue; }

    var id = situations[Math.floor(R() * situations.length)];
    var ex = null;

    if (src === 'recorded') {
      /* A recording is one continuous take with everyone in it — the whole
         exchange, not a single station's line. It plays as one block and
         the gaps inside it are whatever the speakers left. */
      var pick = recBag.take(function (L) {
        var topic = topicOf(id);
        return !L.topic || L.topic === topic;
      });
      if (!pick) { t += 15 + R() * 30; continue; }
      var pr = pairBag.take(null) || PAIRS[0];
      ex = { src:'recorded', units:pr, whole:true,
             lines: [{ cs:'NET', text:pick.name, rec_id:pick.id,
                       dur:pick.secs || 2.5, url:pick.url }] };
    } else if (poolBag) {
      /* Your own exchanges, dealt from the shuffled bag so nothing comes
         round again until the whole pool has been used. */
      var chosenEx = poolBag.take(function (p) { return p.scenario === id; });
      if (!chosenEx) { t += 12 + R() * 25; continue; }

      ex = { src:'generated', units: chosenEx.units.length ? chosenEx.units
               : [chosenEx.lines[0].cs, chosenEx.lines[1] ? chosenEx.lines[1].cs : chosenEx.lines[0].cs],
             lines: chosenEx.lines.map(function (L) {
               return { cs:L.cs, text:L.text,
                        dur: 2.0 + L.text.length * 0.052, url:null };
             }) };
    } else {
      var pair = pairBag.take(null) || PAIRS[0];
      ex = { src:'generated', units:pair,
             lines: linesFor(id, pair[0], pair[1]).map(function (L) {
               return { cs:L.cs, text:L.text,
                        dur: 2.0 + L.text.length * 0.052, url:null };
             }) };
    }

    var ch = channelFor(ex.units[0], ex.units[1]);
    var isThread = THREADS.indexOf(id) >= 0 && R() < thr;
    var tid = isThread ? 'T' + (1000 + Math.floor(R() * 8999)) : null;
    var stepped = R() < dbl;

    ex.lines.forEach(function (ln, i) {
      var d = ln.dur + (ex.src === 'generated' ? R() * 0.8 : 0);
      if (exm !== 'off' && i === 0) d += 1.1;
      tx.push({ t:t, ch:ch, cs:ln.cs, text:ln.text, dur:d, url:ln.url,
                recording_id: ln.rec_id || null,
                thread:tid, scen:id, src:ex.src,
                ex: exm === 'both' || (exm === 'period' && i === 0),
                dbl: stepped && i === 1 });
      air += d;
      t += d;
      if (i < ex.lines.length - 1) {
        t += /wait|say again/i.test(ln.text) ? 5 + R() * 7 : 1 + R() * 3;
      }
    });

    if (isThread && t < dur - 200) {
      var ft = t + 180 + R() * 380;
      ex.lines.slice(0, 2).forEach(function (ln, i) {
        tx.push({ t:ft, ch:ch,
                  cs: (i === 0 ? ex.units[1] : ex.units[0]),
                  text: ln.text.replace('message follows', 'update on your last'),
                  dur: ln.dur, url: ln.url, thread:tid, scen:id, src:ex.src,
                  ex: exm === 'both' || (exm === 'period' && i === 0) });
        air += ln.dur; ft += ln.dur + 1 + R() * 3;
      });
    }

    t += busy ? (12 + R() * 33) : (60 + R() * 150);
    if (--run <= 0) {
      busy = !busy;
      run = busy ? 2 + Math.floor(R() * 4) : 1 + Math.floor(R() * 2);
    }
  }

  tx.sort(function (a, b) { return a.t - b.t; });
  return { tx:tx, dur:dur, air:air, src:src };
}

function compose() {
  written = schedule('generated', rng(seedVal));
  renderComposeOut();
}

function renderComposeOut() {
  var box = $('#genout'), prev = $('#gen-preview');
  if (!written || !written.tx.length) {
    $('#gen-count').textContent = 'nothing yet';
    prev.innerHTML = '<p class="empty">Pick at least one topic above.</p>';
    return;
  }
  $('#gen-count').textContent = written.tx.length + ' messages over ' +
    minutes + ' minutes';

  prev.innerHTML = '';
  written.tx.slice(0, 8).forEach(function (x) {
    var d = document.createElement('div');
    d.className = 'gp';
    d.innerHTML = '<span class="gp-t mono">' + mmss(x.t) + '</span>' +
      '<span class="gp-c mono">' + esc(x.cs) + '</span>' +
      '<span class="gp-x">' + esc(x.text) + '</span>';
    prev.appendChild(d);
  });
  if (written.tx.length > 8) {
    var more = document.createElement('div');
    more.className = 'gp more';
    more.textContent = '\u2026 and ' + (written.tx.length - 8) + ' more';
    prev.appendChild(more);
  }
}

// ==========================================================================
// OFFLINE RADIO PROCESSING
// --------------------------------------------------------------------------
// The same chain the player uses, but rendered ahead of time so the result
// can be saved as a file. Band-pass to the comms passband, hard compression,
// a noise floor, a key-up click and a squelch tail.
//
// The band-pass matters most: speech stops sounding like a computer the
// moment everything outside 300-3400 Hz is thrown away. The squelch tail is
// the cue listeners recognise instantly without being able to name it.
// ==========================================================================

var RADIO_TAIL = 0.28;   // seconds of squelch after the carrier drops
var RADIO_LEAD = 0.10;   // seconds of key-up click before speech

function renderRadio(url, profName) {
  var prof = PROFILE[profName] || PROFILE.handheld;

  return fetch(url)
    .then(function (r) { return r.arrayBuffer(); })
    .then(function (buf) {
      var tmp = new (window.AudioContext || window.webkitAudioContext)();
      return tmp.decodeAudioData(buf).then(function (decoded) {
        tmp.close();
        return decoded;
      });
    })
    .then(function (src) {
      var sr  = src.sampleRate;
      var len = Math.ceil((RADIO_LEAD + src.duration + RADIO_TAIL) * sr);
      var oc  = new (window.OfflineAudioContext || window.webkitOfflineAudioContext)(1, len, sr);

      // --- Speech path ---
      var node = oc.createBufferSource();
      node.buffer = src;

      var hp = oc.createBiquadFilter();
      hp.type = 'highpass'; hp.frequency.value = prof.lo;
      var lp = oc.createBiquadFilter();
      lp.type = 'lowpass';  lp.frequency.value = prof.hi;

      var comp = oc.createDynamicsCompressor();
      comp.threshold.value = -26;
      comp.ratio.value     = 12;
      comp.attack.value    = 0.003;
      comp.release.value   = 0.06;

      var gain = oc.createGain();
      gain.gain.value = 1.6;

      node.connect(hp); hp.connect(lp); lp.connect(comp);
      comp.connect(gain); gain.connect(oc.destination);
      node.start(RADIO_LEAD);

      // --- Noise floor, shaped by the same passband ---
      var nlen  = len;
      var nbuf  = oc.createBuffer(1, nlen, sr);
      var nd    = nbuf.getChannelData(0);
      for (var i = 0; i < nlen; i++) nd[i] = Math.random() * 2 - 1;

      var nsrc = oc.createBufferSource();
      nsrc.buffer = nbuf;
      var nbp = oc.createBiquadFilter();
      nbp.type = 'bandpass';
      nbp.frequency.value = Math.sqrt(prof.lo * prof.hi);
      nbp.Q.value = 0.7;
      var ngain = oc.createGain();
      ngain.gain.value = prof.noise;
      nsrc.connect(nbp); nbp.connect(ngain); ngain.connect(oc.destination);
      nsrc.start(0);

      // --- Key-up click ---
      var clen = Math.floor(sr * 0.018);
      var cbuf = oc.createBuffer(1, clen, sr);
      var cd   = cbuf.getChannelData(0);
      for (var j = 0; j < clen; j++) {
        cd[j] = (Math.random() * 2 - 1) * Math.exp(-9 * j / clen);
      }
      var csrc = oc.createBufferSource();
      csrc.buffer = cbuf;
      var cg = oc.createGain();
      cg.gain.value = 0.22;
      csrc.connect(cg); cg.connect(oc.destination);
      csrc.start(0);

      // --- Squelch tail after the carrier drops ---
      var tlen = Math.floor(sr * RADIO_TAIL);
      var tbuf = oc.createBuffer(1, tlen, sr);
      var td   = tbuf.getChannelData(0);
      for (var k = 0; k < tlen; k++) {
        var env = k < tlen * 0.55 ? 1 : 1 - (k - tlen * 0.55) / (tlen * 0.45);
        td[k] = (Math.random() * 2 - 1) * env;
      }
      var tsrc = oc.createBufferSource();
      tsrc.buffer = tbuf;
      var tbp = oc.createBiquadFilter();
      tbp.type = 'bandpass';
      tbp.frequency.value = 1400;
      tbp.Q.value = 0.6;
      var tg = oc.createGain();
      tg.gain.value = 0.16;
      tsrc.connect(tbp); tbp.connect(tg); tg.connect(oc.destination);
      tsrc.start(RADIO_LEAD + src.duration);

      return oc.startRendering();
    });
}

/* Encode an AudioBuffer as a 16-bit PCM WAV. */
function bufferToWav(buf) {
  var ch  = buf.numberOfChannels;
  var sr  = buf.sampleRate;
  var n   = buf.length;
  var out = new ArrayBuffer(44 + n * ch * 2);
  var v   = new DataView(out);

  function str(off, t) {
    for (var i = 0; i < t.length; i++) v.setUint8(off + i, t.charCodeAt(i));
  }

  str(0, 'RIFF');
  v.setUint32(4, 36 + n * ch * 2, true);
  str(8, 'WAVE');
  str(12, 'fmt ');
  v.setUint32(16, 16, true);
  v.setUint16(20, 1, true);            // PCM
  v.setUint16(22, ch, true);
  v.setUint32(24, sr, true);
  v.setUint32(28, sr * ch * 2, true);
  v.setUint16(32, ch * 2, true);
  v.setUint16(34, 16, true);
  str(36, 'data');
  v.setUint32(40, n * ch * 2, true);

  var off = 44;
  for (var i = 0; i < n; i++) {
    for (var c = 0; c < ch; c++) {
      var x = Math.max(-1, Math.min(1, buf.getChannelData(c)[i]));
      v.setInt16(off, x < 0 ? x * 0x8000 : x * 0x7FFF, true);
      off += 2;
    }
  }
  return new Blob([out], { type: 'audio/wav' });
}

function safeName(t) {
  return String(t || 'recording').trim()
    .replace(/[^\w\s-]/g, '').replace(/\s+/g, '_').slice(0, 60) || 'recording';
}

// ==========================================================================
// THE PLAYER
// --------------------------------------------------------------------------
// Plays a scheduled session so it sounds like a live net rather than a
// playlist. Three things do most of the work:
//
//   Band-pass filtering to roughly 300-3400 Hz. Speech stops sounding like
//   a computer the moment everything outside the comms passband is thrown
//   away. This is the single biggest change.
//
//   A squelch tail — the burst of noise after the carrier drops. Listeners
//   recognise it instantly without being able to name it.
//
//   Silence. Most of a real net is dead air, so the player waits through
//   the gaps rather than running clips back to back.
//
// Recorded clips are routed through the filter chain. Written messages use
// the browser's speech synthesis, which cannot be routed through Web Audio,
// so the noise floor is layered underneath instead.
// ==========================================================================

var AC = null;          // AudioContext
var noiseBuf = null;
var playing = false;
var playT0 = 0;         // wall clock when playback started
var playPos = 0;        // seconds into the session
var playRAF = null;
var playIdx = 0;
var activeCh = 'ALL';
var speed = 10;
var soundOn = true;
var liveNodes = [];

function audio() {
  if (!AC) {
    AC = new (window.AudioContext || window.webkitAudioContext)();
    var n = AC.sampleRate * 2;
    noiseBuf = AC.createBuffer(1, n, AC.sampleRate);
    var d = noiseBuf.getChannelData(0);
    for (var i = 0; i < n; i++) d[i] = Math.random() * 2 - 1;
  }
  if (AC.state === 'suspended') AC.resume();
  return AC;
}

/* Band-limited noise, shaped by the same passband as the speech — receiver
   noise is filtered by the receiver, so unfiltered white noise sounds wrong. */
function noise(gain, dur, prof, when) {
  var ac = audio();
  var src = ac.createBufferSource();
  src.buffer = noiseBuf;
  src.loop = true;

  var bp = ac.createBiquadFilter();
  bp.type = 'bandpass';
  bp.frequency.value = Math.sqrt(prof.lo * prof.hi);
  bp.Q.value = 0.7;

  var g = ac.createGain();
  var t0 = when || ac.currentTime;
  g.gain.setValueAtTime(0, t0);
  g.gain.linearRampToValueAtTime(gain, t0 + 0.01);
  g.gain.setValueAtTime(gain, t0 + dur - 0.05);
  g.gain.linearRampToValueAtTime(0, t0 + dur);

  src.connect(bp); bp.connect(g); g.connect(ac.destination);
  src.start(t0); src.stop(t0 + dur + 0.05);
  liveNodes.push(src);
  return src;
}

/* Key-up click, then squelch tail on release. */
function keyClick(prof) {
  if (!soundOn) return;
  noise(0.18, 0.02, prof);
}

function squelchTail(prof) {
  if (!soundOn) return;
  var ac = audio();
  noise(0.13, 0.18, prof, ac.currentTime + 0.03);
}

/* Play a recorded clip through the radio chain. */
function playClip(url, prof, onEnd) {
  var ac = audio();
  fetch(url).then(function (r) { return r.arrayBuffer(); })
    .then(function (b) { return ac.decodeAudioData(b); })
    .then(function (buf) {
      var src = ac.createBufferSource();
      src.buffer = buf;

      var hp = ac.createBiquadFilter();
      hp.type = 'highpass'; hp.frequency.value = prof.lo;
      var lp = ac.createBiquadFilter();
      lp.type = 'lowpass';  lp.frequency.value = prof.hi;

      // Heavy compression — radio has almost no dynamic range
      var comp = ac.createDynamicsCompressor();
      comp.threshold.value = -26;
      comp.ratio.value = 12;
      comp.attack.value = 0.003;
      comp.release.value = 0.06;

      var g = ac.createGain();
      g.gain.value = 1.5;

      src.connect(hp); hp.connect(lp); lp.connect(comp);
      comp.connect(g); g.connect(ac.destination);

      noise(prof.noise, buf.duration + 0.1, prof);
      src.start();
      liveNodes.push(src);
      src.onended = function () { squelchTail(prof); if (onEnd) onEnd(); };
    })
    .catch(function () { if (onEnd) onEnd(); });
}

/* Speak a written message. Speech synthesis cannot be routed through Web
   Audio, so the noise floor is played alongside it rather than under it. */
function speak(text, prof, onEnd) {
  if (!('speechSynthesis' in window)) { if (onEnd) onEnd(); return; }
  window.speechSynthesis.cancel();
  var u = new SpeechSynthesisUtterance(text);
  u.rate = 1.05;
  u.pitch = 0.9;
  u.onend = function () { squelchTail(prof); if (onEnd) onEnd(); };
  u.onerror = function () { if (onEnd) onEnd(); };
  noise(prof.noise * 0.8, Math.max(1.5, text.length * 0.06), prof);
  window.speechSynthesis.speak(u);
}

function stopAudio() {
  liveNodes.forEach(function (n) { try { n.stop(); } catch (e) {} });
  liveNodes = [];
  if ('speechSynthesis' in window) window.speechSynthesis.cancel();
}

// ---- Player view ----------------------------------------------------------

function openPlayer(src) {
  if (src) playSrc = src;

  session = (playSrc === 'recorded')
    ? schedule('recorded', rng(seedVal))
    : (written || schedule('generated', rng(seedVal)));

  $('#p-src').textContent = playSrc === 'recorded'
    ? 'Your recordings' : 'Written by computer';

  var msg = $('#p-msg');
  if (!session || !session.tx.length) {
    msg.innerHTML = playSrc === 'recorded'
      ? '<span class="bad">Nothing recorded for these topics yet. Record some messages first.</span>'
      : '<span class="bad">Nothing written yet. Pick some topics first.</span>';
    $('#p-play').disabled = true;
  } else {
    msg.textContent = session.tx.length + ' messages over ' + minutes + ' minutes.';
    $('#p-play').disabled = false;
  }

  buildChannelPicker();
  buildTicks();
  resetPlayback();
}

function buildChannelPicker() {
  var host = $('#chan-pick');
  host.innerHTML = '';
  ['ALL'].concat(Object.keys(CH)).forEach(function (ch) {
    var b = document.createElement('button');
    b.type = 'button';
    b.className = 'chan';
    b.dataset.on = (ch === activeCh) ? '1' : '0';
    b.textContent = ch === 'ALL' ? 'Both' : (ch === 'COMMAND' ? 'Command' : 'Admin');
    b.addEventListener('click', function () {
      activeCh = ch;
      buildChannelPicker();
    });
    host.appendChild(b);
  });
}

function buildTicks() {
  var host = $('#ticks');
  if (!host || !session) return;
  host.innerHTML = '';
  var dur = session.dur;
  var step = dur <= 600 ? 60 : dur <= 1800 ? 300 : 600;
  for (var s = 0; s <= dur; s += step) {
    var d = document.createElement('span');
    d.className = 'tick';
    d.style.left = (s / dur * 100) + '%';
    d.textContent = mmss(s);
    host.appendChild(d);
  }
}

function resetPlayback() {
  playing = false;
  playPos = 0;
  playIdx = 0;
  $('#p-log').innerHTML = '';
  $('#p-clock').textContent = '00:00';
  $('#scrub-fill').style.width = '0%';
  $('#scrub-head').style.left = '0%';
  $('#p-status').textContent = 'Stopped';
  $('#p-play').textContent = 'Start listening';
  showIdle();
}

function showIdle() {
  $('#rx-live').hidden = true;
  $('#rx-idle').hidden = false;
  $('#p-level').style.width = '0%';
}

function showLive(x) {
  $('#rx-idle').hidden = true;
  $('#rx-live').hidden = false;

  /* A recorded take carries several speakers in one block, so there is no
     single station to name. Show it as net traffic instead. */
  var whole = x.cs === 'NET';
  $('#p-cs').textContent = whole ? 'NET' : x.cs;

  var prof = whole ? 'handheld' : profOf(x.cs);
  if (whole) {
    $('#p-sig').textContent = 'several stations';
    $('#p-sig').className = 'rx-sig mixed';
  } else {
    var bars = prof === 'base' ? 5 : prof === 'handheld' ? 4 : prof === 'air' ? 4 : 2;
    var sig = '';
    for (var i = 0; i < 5; i++) sig += (i < bars) ? '\u2588' : '\u2591';
    $('#p-sig').textContent = sig;
    $('#p-sig').className = 'rx-sig ' + prof;
  }

  $('#p-text').innerHTML = (x.ex ? '<span class="exlbl">EXERCISE</span> ' : '') +
    esc(x.text);
  $('#p-level').style.width = (55 + Math.random() * 40) + '%';
}

function logLine(x) {
  var tb = $('#p-log');
  var tr = document.createElement('tr');
  tr.className = 'in' + (x.thread ? ' thr' : '');
  tr.innerHTML =
    '<td class="t">' + mmss(x.t) + '</td>' +
    '<td class="t">' + (x.ch === 'COMMAND' ? 'Command' : 'Admin') + '</td>' +
    '<td class="cs">' + (x.cs === 'NET'
      ? '<span class="net-tag">NET</span>' : esc(x.cs)) + '</td>' +
    '<td><span class="src ' + x.src + '">' +
      (x.src === 'recorded' ? 'REC' : 'GEN') + '</span></td>' +
    '<td class="msg">' + (x.ex ? '<span class="exlbl">EXERCISE</span>' : '') +
      esc(x.text) + (x.dbl ? ' <span class="dbl">[talked over]</span>' : '') + '</td>';
  tb.appendChild(tr);
  var wrap = $('#p-log-wrap');
  wrap.scrollTop = wrap.scrollHeight;
}

function startPlayback() {
  if (!session || !session.tx.length) return;
  if (playing) { pausePlayback(); return; }

  audio();
  playing = true;
  playT0 = performance.now() / 1000 - playPos / speed;
  $('#p-play').textContent = 'Pause';
  $('#p-status').textContent = 'Listening';
  tick();
}

function pausePlayback() {
  playing = false;
  cancelAnimationFrame(playRAF);
  stopAudio();
  $('#p-play').textContent = 'Resume';
  $('#p-status').textContent = 'Paused';
  showIdle();
}

function stopPlayback() {
  playing = false;
  cancelAnimationFrame(playRAF);
  stopAudio();
}

function tick() {
  if (!playing) return;
  var dur = session.dur;
  playPos = (performance.now() / 1000 - playT0) * speed;

  if (playPos >= dur) {
    playPos = dur;
    playing = false;
    $('#p-play').textContent = 'Start again';
    $('#p-status').textContent = 'Finished';
    showIdle();
    updateScrub();
    return;
  }

  while (playIdx < session.tx.length && session.tx[playIdx].t <= playPos) {
    var x = session.tx[playIdx++];
    if (activeCh !== 'ALL' && x.ch !== activeCh) continue;

    var prof = PROFILE[profOf(x.cs)] || PROFILE.handheld;
    showLive(x);
    logLine(x);

    if (soundOn) {
      keyClick(prof);
      if (x.src === 'recorded' && x.url) playClip(x.url, prof, null);
      else if (speed <= 4) speak(x.text, prof, null);
      else noise(prof.noise * 1.4, Math.min(0.5, x.dur / speed), prof);
    }

    (function (until) {
      setTimeout(function () {
        if (playing && playPos >= until - 0.5) showIdle();
      }, Math.max(200, (x.dur / speed) * 1000));
    })(x.t + x.dur);
  }

  $('#p-clock').textContent = mmss(playPos);
  updateScrub();
  playRAF = requestAnimationFrame(tick);
}

function updateScrub() {
  var pc = (playPos / session.dur * 100).toFixed(2) + '%';
  $('#scrub-fill').style.width = pc;
  $('#scrub-head').style.left = pc;
}

// ==========================================================================
// RECORDING  (shared by the message studio and the voice cards)
// ==========================================================================

function startRec(key, card, onDone) {
  if (!navigator.mediaDevices || !window.MediaRecorder) {
    var s0 = $('.sline-st', card) || $('.st', card);
    if (s0) s0.textContent = 'Recording is not available in this browser';
    return;
  }

  navigator.mediaDevices.getUserMedia({
    audio: { echoCancellation:false, noiseSuppression:false, autoGainControl:false }
  }).then(function (stream) {
    recTarget = key;
    recCard = card;
    var chunks = [], secs = 0, peaked = false;
    var st = $('.sline-st', card) || $('.st', card);
    var btn = $('button', card) || $('[data-act=rec]', card);

    recorder = new MediaRecorder(stream);
    recorder.ondataavailable = function (e) { if (e.data.size) chunks.push(e.data); };
    recorder.onstop = function () {
      var blob = new Blob(chunks, { type: chunks.length ? chunks[0].type : 'audio/webm' });
      var url = URL.createObjectURL(blob);
      stream.getTracks().forEach(function (t) { t.stop(); });
      recorder = null; recTarget = null;
      onDone(url, secs, peaked);
    };

    var ac = new (window.AudioContext || window.webkitAudioContext)();
    var an = ac.createAnalyser(); an.fftSize = 512;
    ac.createMediaStreamSource(stream).connect(an);
    var buf = new Uint8Array(an.frequencyBinCount);
    var bar = $('.meter i', card);

    (function draw() {
      an.getByteTimeDomainData(buf);
      var peak = 0;
      for (var i = 0; i < buf.length; i++) {
        var v = Math.abs(buf[i] - 128) / 128;
        if (v > peak) peak = v;
      }
      if (peak > 0.98) peaked = true;
      if (bar) bar.style.width = Math.min(100, peak * 140) + '%';
      meterRAF = requestAnimationFrame(draw);
    })();

    recorder.start();
    if (btn) btn.textContent = 'Stop';
    if (st) st.innerHTML = '<span class="dot no"></span>recording\u2026';

    recTimer = setInterval(function () {
      secs += 0.2;
      if (st) st.innerHTML = '<span class="dot no"></span>recording\u2026 ' +
        secs.toFixed(0) + ' s' + (peaked ? ' &mdash; too loud' : '');
    }, 200);

    card._cleanup = function () {
      clearInterval(recTimer);
      cancelAnimationFrame(meterRAF);
      if (bar) bar.style.width = '0';
      ac.close();
    };
  }).catch(function () {
    var st = $('.sline-st', card) || $('.st', card);
    if (st) st.textContent = 'No microphone — check browser permissions';
  });
}

var recCard = null;   // whichever element is currently showing the meter

function stopRec() {
  if (!recorder) return;
  if (recCard && recCard._cleanup) { recCard._cleanup(); recCard._cleanup = null; }
  /* Belt and braces — clear any meter left running elsewhere. */
  $$('.sline, .rec, .rec-panel, .vb-row, .mini-rec').forEach(function (c) {
    if (c._cleanup) { c._cleanup(); c._cleanup = null; }
  });
  recCard = null;
  recorder.stop();
}

// ---- Message recorder ----------------------------------------------------
// No script, no prompting. Press record, speak, stop. Then name the
// recording and say who it was and roughly what it was about — that is all
// the player needs to schedule it.
// --------------------------------------------------------------------------

function buildPeopleGrid() {
  var host = $('#people-grid');
  if (!host) return;
  host.innerHTML = '';

  STATIONS.forEach(function (st, i) {
    var d = document.createElement('div');
    d.className = 'person';
    d.innerHTML =
      '<div class="person-cs mono">' + esc(st.cs) + '</div>' +
      '<input type="text" value="' + esc(st.speaker) +
        '" placeholder="name" aria-label="Who plays ' + esc(st.cs) + '">' +
      '<div class="person-r">' + esc(st.role) + '</div>';
    host.appendChild(d);

    $('input', d).addEventListener('input', function () {
      STATIONS[i].speaker = this.value;
      buildTakeList();
      saveState();
      refreshMenu();
    });
  });
}

function startFreeRecording() {
  var panel = $('.rec-panel');
  var btn = $('#rec-btn');
  var key = 'take:free';

  if (recorder && recTarget === key) { stopRec(); return; }
  if (recorder) stopRec();

  startRec(key, panel, function (url, secs) {
    var n = library.length + 1;
    library.push({
      id: 'R' + Date.now().toString(36),
      name: 'Recording ' + n,
      topic: firstLiveTopic(),
      prof: 'handheld',
      url: url,
      secs: secs
    });
    saveState();
    uploadBlob('recording', library[library.length - 1].id, url);
    btn.textContent = 'Record';
    $('#rec-st').innerHTML = '<span class="dot ok"></span>Saved as Recording ' +
      n + '. Rename it below.';
    buildTakeList();
    refreshAll();
  });

  btn.textContent = 'Stop';
}

/* Which topic a given situation belongs to, so recordings tagged by topic
   can be matched to the scheduler's situation picks. */
function topicOf(situationId) {
  for (var i = 0; i < TOPICS.length; i++) {
    if (TOPICS[i].items.indexOf(situationId) >= 0) return TOPICS[i].id;
  }
  return null;
}

function firstLiveTopic() {
  for (var i = 0; i < TOPICS.length; i++) {
    if (topicsOn[TOPICS[i].id]) return TOPICS[i].id;
  }
  return TOPICS[0].id;
}

function buildTakeList() {
  var host = $('#takes-list');
  if (!host) return;

  if (!library.length) {
    host.innerHTML = '<p class="empty">Nothing recorded yet. Press Record ' +
      'above, say whatever the message is, then press Stop.</p>';
    return;
  }

  host.innerHTML =
    '<div class="takes-h">' +
      '<span>What this recording is</span><span>About</span>' +
      '<span>Signal</span><span>Length</span><span></span>' +
    '</div>';

  library.forEach(function (L, i) {
    var row = document.createElement('div');
    row.className = 'take-row';
    row.innerHTML =
      '<input type="text" class="tk-name" value="' + esc(L.name) +
        '" aria-label="Name of recording ' + (i + 1) + '">' +
      '<select class="tk-topic" aria-label="What it is about">' +
        TOPICS.map(function (T) {
          return '<option value="' + T.id + '"' +
            (T.id === L.topic ? ' selected' : '') + '>' + esc(T.name) + '</option>';
        }).join('') +
      '</select>' +
      '<select class="tk-prof" aria-label="Signal quality">' +
        SIGNALS.map(function (g) {
          return '<option value="' + g.id + '"' +
            (g.id === (L.prof || 'handheld') ? ' selected' : '') + '>' +
            esc(g.label) + '</option>';
        }).join('') +
      '</select>' +
      '<span class="tk-secs mono">' + L.secs.toFixed(0) + ' s</span>' +
      '<div class="tk-a">' +
        '<button class="btn sm" data-a="play" title="The raw recording">Play</button>' +
        '<button class="btn sm" data-a="radio" title="With radio filter — this is the real output">Radio</button>' +
        '<button class="btn sm" data-a="save" title="Download the radio-filtered version">Save</button>' +
        '<button class="btn sm" data-a="del">Delete</button>' +
      '</div>';
    host.appendChild(row);

    $('.tk-name', row).addEventListener('input', function () {
      L.name = this.value;
      saveState();
      refreshMenu();
    });
    $('.tk-topic', row).addEventListener('change', function () {
      L.topic = this.value;
      saveState();
      refreshAll();
    });
    $('.tk-prof', row).addEventListener('change', function () {
      L.prof = this.value;
      saveState();
    });
    $('[data-a=play]', row).addEventListener('click', function () {
      new Audio(L.url).play();
    });

    /* Hear it as it will actually come out — band-limited, compressed, with
       a noise floor and a squelch tail. */
    $('[data-a=radio]', row).addEventListener('click', function () {
      var btn = this;
      btn.disabled = true; btn.textContent = '\u2026';

      var done = function () { btn.disabled = false; btn.textContent = 'Radio'; };

      if (server.up && server.fx) {
        /* Your own DSP chain, so this is exactly what the scripts produce. */
        runJob('/api/render-one', { id: L.id, profile: L.prof || 'handheld' })
          .then(function (j) {
            new Audio('/api/download/' + j.files[0]).play();
            done();
          })
          .catch(done);
      } else {
        renderRadio(L.url, L.prof || 'handheld').then(function (rendered) {
          var a = new Audio(URL.createObjectURL(bufferToWav(rendered)));
          a.play();
          a.onended = function () { URL.revokeObjectURL(a.src); };
          done();
        }).catch(done);
      }
    });

    $('[data-a=save]', row).addEventListener('click', function () {
      var btn = this;
      btn.disabled = true; btn.textContent = '\u2026';
      var done = function () { btn.disabled = false; btn.textContent = 'Save'; };

      if (server.up && server.fx) {
        runJob('/api/render-one', { id: L.id, profile: L.prof || 'handheld' })
          .then(function (j) {
            var a = document.createElement('a');
            a.href = '/api/download/' + j.files[0];
            a.download = safeName(L.name) + '_radio.wav';
            a.click();
            done();
          })
          .catch(done);
      } else {
        renderRadio(L.url, L.prof || 'handheld').then(function (rendered) {
          var a = document.createElement('a');
          a.href = URL.createObjectURL(bufferToWav(rendered));
          a.download = safeName(L.name) + '_radio.wav';
          a.click();
          setTimeout(function () { URL.revokeObjectURL(a.href); }, 1500);
          done();
        }).catch(done);
      }
    });
    $('[data-a=del]', row).addEventListener('click', function () {
      URL.revokeObjectURL(L.url);
      library.splice(i, 1);
      buildTakeList();
      saveState();
      refreshAll();
    });
  });
}

// ---- Stations -------------------------------------------------------------

function buildVoices() {
  var tb = $('#voice-rows');
  if (!tb) return;
  tb.innerHTML = '';

  STATIONS.forEach(function (s, i) {
    var tr = document.createElement('tr');
    tr.innerHTML =
      '<td><input type="text" data-f="cs" data-i="' + i + '" value="' + esc(s.cs) +
        '" style="font-weight:700" aria-label="Station name"></td>' +
      '<td><input type="text" data-f="role" data-i="' + i + '" value="' + esc(s.role) +
        '" style="font-family:var(--fb);font-size:12.5px" aria-label="Role"></td>' +
      '<td><input type="text" data-f="speaker" data-i="' + i + '" value="' + esc(s.speaker) +
        '" placeholder="name" style="font-family:var(--fb);font-size:12.5px" ' +
        'aria-label="Played by"></td>' +
      '<td><select data-f="prof" data-i="' + i + '" aria-label="Signal">' +
        SIGNALS.map(function (g) {
          return '<option value="' + g.id + '"' + (g.id === s.prof ? ' selected' : '') +
            '>' + g.label + '</option>';
        }).join('') + '</select></td>' +
      '<td data-vc="' + i + '" class="mono" style="font-size:11.5px"></td>';
    tb.appendChild(tr);
  });

  $$('[data-f]', tb).forEach(function (el) {
    el.addEventListener('input', function () {
      var i = +el.dataset.i, f = el.dataset.f, old = STATIONS[i].cs;
      STATIONS[i][f] = el.value;
      if (f === 'cs' && refs[old]) { refs[el.value] = refs[old]; delete refs[old]; }
      if (f === 'cs') rebuildRoster();
      if (f === 'prof') checkSignals();
      refreshAll();
    });
  });

  checkSignals();
  updateVoiceCells();
}

function updateVoiceCells() {
  STATIONS.forEach(function (s, i) {
    var c = $('[data-vc="' + i + '"]');
    if (!c) return;
    c.innerHTML = refs[s.cs]
      ? '<span class="dot ok"></span>' + refs[s.cs].secs.toFixed(0) + ' s'
      : '<span class="dot wait"></span>none';
  });
}

function checkSignals() {
  var weak = STATIONS.filter(function (s) { return s.prof === 'distant'; });
  var el = $('#conflict');
  if (!el) return;
  el.innerHTML = weak.length > 1
    ? '<span class="bad">' + weak.length + ' stations set to Weak.</span> One weak ' +
      'signal makes the others sound solid. Several just sound broken.'
    : 'Each station has its own voice and signal.';
}

function buildChannelTable() {
  var a = $('#ch-command'), b = $('#ch-admin');
  if (a) a.textContent = CH.COMMAND.join('  ');
  if (b) b.textContent = CH.ADMIN.join('  ');
}

/* The voice pool. Each card is a PERSON, not a station — record once, then
   cast them onto stations separately. */
function buildRecorders() {
  var host = $('#rec-grid');
  if (!host) return;
  host.innerHTML = '';

  voices.forEach(function (v, i) {
    var playing = STATIONS.filter(function (s) { return assign[s.cs] === v.id; })
                          .map(function (s) { return s.cs; });

    var d = document.createElement('div');
    d.className = 'rec has';
    d.innerHTML =
      '<div class="cs">Voice ' + (i + 1) + '</div>' +
      '<input type="text" class="spk" value="' + esc(v.name) +
        '" placeholder="Whose voice is this?" aria-label="Name for voice ' + (i+1) + '">' +
      '<div class="meter"><i></i></div>' +
      '<div class="st"><span class="dot ok"></span>' + v.secs.toFixed(0) + ' s recorded</div>' +
      '<div class="role">' + (playing.length
        ? 'Playing ' + playing.join(', ')
        : '<span style="color:var(--ink-faint)">not cast yet</span>') + '</div>' +
      '<div class="acts">' +
        '<button class="btn sm" data-act="rerec">Re-record</button>' +
        '<button class="btn sm" data-act="del">Delete</button>' +
      '</div>' +
      '<div class="player-mini"><audio controls src="' + v.url + '"></audio></div>';
    host.appendChild(d);

    $('.spk', d).addEventListener('input', function () {
      v.name = this.value;
      refreshCastLabels();
      refreshMenu();
    });

    $('[data-act=rerec]', d).addEventListener('click', function () {
      var key = 'voice:' + v.id;
      if (recorder && recTarget === key) { stopRec(); return; }
      if (recorder) stopRec();
      startRec(key, d, function (url, secs) {
        URL.revokeObjectURL(v.url);
        v.url = url; v.secs = secs;
        syncRefs(); buildRecorders(); buildVoicePanel(); refreshAll();
      });
    });

    $('[data-act=del]', d).addEventListener('click', function () {
      URL.revokeObjectURL(v.url);
      voices.splice(i, 1);
      Object.keys(assign).forEach(function (cs) {
        if (assign[cs] === v.id) delete assign[cs];
      });
      if (autoVoice) castAutomatically(); else syncRefs();
      buildRecorders(); buildVoicePanel(); updateVoiceCells(); refreshAll();
    });
  });

  /* An always-present card for adding another person. */
  var add = document.createElement('div');
  add.className = 'rec add';
  add.innerHTML =
    '<div class="cs">Add a voice</div>' +
    '<div class="role">Half a minute is plenty. Read flatly &mdash; real ' +
      'operators sound bored.</div>' +
    '<div class="meter"><i></i></div>' +
    '<div class="st">Ready when you are</div>' +
    '<div class="acts"><button class="btn sm pri" data-act="rec">Record</button></div>';
  host.appendChild(add);

  $('[data-act=rec]', add).addEventListener('click', function () {
    var key = 'voice:new';
    if (recorder && recTarget === key) { stopRec(); return; }
    if (recorder) stopRec();
    startRec(key, add, function (url, secs) {
      addVoice('', url, secs);
      if (autoVoice) castAutomatically(); else syncRefs();
      buildRecorders(); buildVoicePanel(); updateVoiceCells(); refreshAll();
    });
  });
}

// ==========================================================================
// STATUS AND MENU
// ==========================================================================

// ==========================================================================
// VOICE POOL AND CASTING
// --------------------------------------------------------------------------
// Recordings belong to people, not to stations. Casting is a separate step,
// so one person can cover several stations and you can re-cast without
// re-recording anybody.
//
// The one rule that matters: two stations that talk to each other must not
// share a voice, or the exchange sounds like one person answering himself.
// The automatic casting below enforces that; manual casting warns about it.
// ==========================================================================

function addVoice(name, url, secs) {
  var v = { id: 'V' + Date.now().toString(36), name: name || '', url: url, secs: secs };
  voices.push(v);
  saveState();
  uploadBlob('voice', v.id, url);
  return v;
}

function voiceById(id) {
  for (var i = 0; i < voices.length; i++) if (voices[i].id === id) return voices[i];
  return null;
}

/* Do two stations ever appear in the same exchange? */
function talkTo(a, b) {
  for (var i = 0; i < PAIRS.length; i++) {
    if ((PAIRS[i][0] === a && PAIRS[i][1] === b) ||
        (PAIRS[i][1] === a && PAIRS[i][0] === b)) return true;
  }
  return false;
}

/* Cast every station, spreading the available voices as widely as possible
   and never giving the same voice to two stations that speak to each other. */
function castAutomatically() {
  assign = {};
  if (!voices.length) { syncRefs(); return; }

  var used = {};   // voice id -> [callsigns already using it]

  STATIONS.forEach(function (s) {
    var best = null, bestLoad = Infinity;

    voices.forEach(function (v) {
      var holders = used[v.id] || [];
      var clash = holders.some(function (cs) { return talkTo(cs, s.cs); });
      if (clash) return;
      if (holders.length < bestLoad) { best = v; bestLoad = holders.length; }
    });

    /* Every voice clashes — fall back to the least-used one rather than
       leaving the station silent. */
    if (!best) {
      voices.forEach(function (v) {
        var n = (used[v.id] || []).length;
        if (n < bestLoad) { best = v; bestLoad = n; }
      });
    }

    if (best) {
      assign[s.cs] = best.id;
      (used[best.id] = used[best.id] || []).push(s.cs);
    }
  });

  syncRefs();
}

/* Keep `refs` in step with the casting, since the recorder cards and the
   station table both read from it. */
function syncRefs() {
  refs = {};
  STATIONS.forEach(function (s) {
    var v = voiceById(assign[s.cs]);
    if (v) refs[s.cs] = { url: v.url, secs: v.secs, name: v.name };
  });
}

/* Which castings put the same voice on both ends of a conversation. */
function castingClashes() {
  var out = [];
  PAIRS.forEach(function (p) {
    if (assign[p[0]] && assign[p[0]] === assign[p[1]]) out.push(p);
  });
  return out;
}

/* Wire the compact "Add a voice" block that appears on every screen where
   casting is shown. */
/* Update the casting labels in place. A full rebuild while somebody is
   typing a name would steal focus mid-word. */
function refreshCastLabels() {
  STATIONS.forEach(function (st) {
    var v = voiceById(assign[st.cs]);
    $$('[data-castv="' + st.cs + '"]').forEach(function (cell) {
      cell.innerHTML = v
        ? esc(v.name || 'unnamed voice') +
          ' <span class="cast-secs mono">' + v.secs.toFixed(0) + ' s</span>'
        : '<span class="cast-none">no voice</span>';
    });
    $$('[data-cast-for="' + st.cs + '"]').forEach(function (sel) {
      $$('option', sel).forEach(function (o) {
        var ov = voiceById(o.value);
        if (ov) o.textContent = (ov.name || 'unnamed') + ' \u2014 ' +
          ov.secs.toFixed(0) + ' s';
      });
    });
  });

  /* And the "playing" column in the bank. */
  $$('.vb-row').forEach(function (row, i) {
    var v = voices[i];
    if (!v) return;
    var playing = STATIONS.filter(function (st) { return assign[st.cs] === v.id; })
                          .map(function (st) { return st.cs; });
    var cell = $('.vb-p', row);
    if (cell) {
      cell.innerHTML = playing.length ? esc(playing.join(', '))
                                      : '<span class="cast-none">not cast</span>';
    }
  });
}

function wireMiniRecorder(host) {
  var mini = $('[data-mini]', host);
  if (!mini) return;
  var btn = $('[data-act=rec]', mini);
  btn.addEventListener('click', function () {
    var key = 'voice:new';
    if (recorder && recTarget === key) { stopRec(); return; }
    if (recorder) stopRec();
    startRec(key, mini, function (url, secs) {
      addVoice('', url, secs);
      if (autoVoice) castAutomatically(); else syncRefs();
      buildRecorders(); buildVoicePanel(); updateVoiceCells(); refreshAll();
    });
  });
}

function buildVoicePanel() {
  /* The compose screen gets the inline recorder because there is no other
     way to add a voice from there. The stations page has its own card grid
     above, so it only needs the casting table. */
  var a = $('#voice-panel');
  if (a) renderVoicePanel(a, true);
  var b = $('#voice-panel-2');
  if (b) renderVoicePanel(b, false);
}

function renderVoicePanel(host, withRecorder) {
  if (!host) return;

  /* The recorder lives here as well as on the stations page, so nobody has
     to leave the screen they are working on just to add a voice. */
  var recorderHtml =
    '<div class="mini-rec" data-mini>' +
      '<div class="mini-l">' +
        '<div class="mini-n">Add a voice</div>' +
        '<div class="mini-b">Half a minute. Read flatly &mdash; real operators ' +
          'sound bored.</div>' +
        '<div class="meter"><i></i></div>' +
        '<div class="st">Ready when you are</div>' +
      '</div>' +
      '<div class="mini-a">' +
        '<button class="btn sm pri" data-act="rec">Record</button>' +
      '</div>' +
    '</div>';

  if (!voices.length) {
    host.innerHTML =
      '<p class="empty" style="padding:14px 2px">No voices yet. Record at ' +
      'least one and the stations will be cast automatically.</p>' +
      (withRecorder ? recorderHtml : '');
    if (withRecorder) wireMiniRecorder(host);
    return;
  }

  var clashes = castingClashes();

  host.innerHTML =
    '<div class="cast-mode">' +
      '<button class="pill" data-cast="auto" data-on="' + (autoVoice ? '1' : '0') + '">' +
        'Assign automatically<span class="pn">spread evenly, no clashes</span></button>' +
      '<button class="pill" data-cast="manual" data-on="' + (autoVoice ? '0' : '1') + '">' +
        'Choose myself<span class="pn">pick who plays each station</span></button>' +
    '</div>' +
    '<div class="cast-list"></div>' +
    '<p class="note cast-note"></p>' +
    (withRecorder
      ? '<div class="voice-bank"><div class="vb-h">Voices you have recorded</div>' +
        '<div class="vb-list"></div></div>' + recorderHtml
      : '');

  var list = $('.cast-list', host);
  STATIONS.forEach(function (s) {
    var v = voiceById(assign[s.cs]);
    var clash = clashes.some(function (p) { return p[0] === s.cs || p[1] === s.cs; });

    var row = document.createElement('div');
    row.className = 'cast-row' + (clash ? ' clash' : '');
    row.innerHTML =
      '<span class="cast-cs mono">' + esc(s.cs) + '</span>' +
      '<span class="cast-role">' + esc(s.role) + '</span>' +
      (autoVoice
        ? '<span class="cast-v" data-castv="' + esc(s.cs) + '">' + (v
            ? esc(v.name || 'unnamed voice') +
              ' <span class="cast-secs mono">' + v.secs.toFixed(0) + ' s</span>'
            : '<span class="cast-none">no voice</span>') + '</span>'
        : '<select data-cast-for="' + esc(s.cs) + '" aria-label="Voice for ' + esc(s.cs) + '">' +
            '<option value="">no voice</option>' +
            voices.map(function (vv) {
              return '<option value="' + vv.id + '"' +
                (assign[s.cs] === vv.id ? ' selected' : '') + '>' +
                esc(vv.name || 'unnamed') + ' \u2014 ' + vv.secs.toFixed(0) + ' s</option>';
            }).join('') +
          '</select>') +
      (v ? '<button class="btn sm" data-hear="' + v.id + '">Hear</button>'
         : '<span></span>');
    list.appendChild(row);
  });

  var note = $('.cast-note', host);
  if (clashes.length) {
    note.innerHTML = '<span class="bad">' + clashes.length +
      (clashes.length === 1 ? ' pair shares' : ' pairs share') + ' a voice.</span> ' +
      clashes.map(function (p) { return p[0] + ' and ' + p[1]; }).join(', ') +
      ' talk to each other, so those exchanges will sound like one person ' +
      'answering himself. Record another voice, or re-cast.';
    note.style.borderLeftColor = 'var(--flash)';
  } else if (voices.length < STATIONS.length) {
    note.innerHTML = voices.length + ' voices covering ' + STATIONS.length +
      ' stations. Nobody who talks to each other shares a voice, so this ' +
      'works &mdash; but more voices sound better.';
    note.style.borderLeftColor = 'var(--olive)';
  } else {
    note.innerHTML = 'Every station has its own voice.';
    note.style.borderLeftColor = 'var(--olive)';
  }

  /* The bank: rename, re-record or delete a voice without leaving. */
  var bank = $('.vb-list', host);
  if (bank) {
    bank.innerHTML = '';
    voices.forEach(function (v, i) {
      var playing = STATIONS.filter(function (s) { return assign[s.cs] === v.id; })
                            .map(function (s) { return s.cs; });
      var row = document.createElement('div');
      row.className = 'vb-row';
      row.innerHTML =
        '<input type="text" class="vb-name" value="' + esc(v.name) +
          '" placeholder="Voice ' + (i + 1) + '" aria-label="Name for voice ' + (i+1) + '">' +
        '<span class="vb-m mono">' + v.secs.toFixed(0) + ' s</span>' +
        '<span class="vb-p">' + (playing.length
          ? esc(playing.join(', '))
          : '<span class="cast-none">not cast</span>') + '</span>' +
        '<div class="meter"><i></i></div>' +
        '<div class="vb-a">' +
          '<button class="btn sm" data-act="hear">Hear</button>' +
          '<button class="btn sm" data-act="rerec">Re-record</button>' +
          '<button class="btn sm" data-act="del">Delete</button>' +
        '</div>';
      bank.appendChild(row);

      $('.vb-name', row).addEventListener('input', function () {
        v.name = this.value;
        refreshCastLabels();
        buildRecorders();
        refreshMenu();
      });

      $('[data-act=hear]', row).addEventListener('click', function () {
        new Audio(v.url).play();
      });

      $('[data-act=rerec]', row).addEventListener('click', function () {
        var key = 'voice:' + v.id;
        if (recorder && recTarget === key) { stopRec(); return; }
        if (recorder) stopRec();
        startRec(key, row, function (url, secs) {
          URL.revokeObjectURL(v.url);
          v.url = url; v.secs = secs;
          syncRefs(); buildRecorders(); buildVoicePanel(); refreshAll();
        });
      });

      $('[data-act=del]', row).addEventListener('click', function () {
        URL.revokeObjectURL(v.url);
        voices.splice(i, 1);
        Object.keys(assign).forEach(function (cs) {
          if (assign[cs] === v.id) delete assign[cs];
        });
        if (autoVoice) castAutomatically(); else syncRefs();
        buildRecorders(); buildVoicePanel(); updateVoiceCells(); refreshAll();
      });
    });
  }

  if (withRecorder) wireMiniRecorder(host);

  $$('[data-cast]', host).forEach(function (b) {
    b.addEventListener('click', function () {
      autoVoice = (b.getAttribute('data-cast') === 'auto');
      if (autoVoice) castAutomatically();
      buildVoicePanel();
      refreshMenu();
    });
  });

  $$('[data-cast-for]', host).forEach(function (sel) {
    sel.addEventListener('change', function () {
      var cs = sel.getAttribute('data-cast-for');
      if (sel.value) assign[cs] = sel.value;
      else delete assign[cs];
      syncRefs();
      buildVoicePanel();
      buildRecorders();
      updateVoiceCells();
      refreshMenu();
    });
  });

  $$('[data-hear]', host).forEach(function (b) {
    b.addEventListener('click', function () {
      var v = voiceById(b.getAttribute('data-hear'));
      if (!v) return;
      var a = new Audio(v.url);
      a.play();
    });
  });
}

function refreshMenu() {
  var recCount = library.length;
  $('#m-rec').textContent = recCount
    ? recCount + (recCount === 1 ? ' recording' : ' recordings')
    : 'no messages recorded';

  $('#m-gen').textContent = (written && written.tx.length)
    ? written.tx.length + ' messages \u00b7 ' +
      (pool ? pool.length + ' loaded from file' : 'built-in examples')
    : (pool ? pool.length + ' exchanges loaded' : 'no messages written');

  var recReady = schedule('recorded', rng(seedVal));
  $('#m-prec').textContent = (recReady && recReady.tx.length)
    ? 'ready \u2014 ' + recReady.tx.length + ' messages'
    : 'record something first';
  $('#m-prec').className = 'mc-s' + (recReady && recReady.tx.length ? ' ready' : '');

  $('#m-pgen').textContent = (written && written.tx.length)
    ? 'ready \u2014 ' + written.tx.length + ' messages'
    : 'pick some topics first';
  $('#m-pgen').className = 'mc-s' + (written && written.tx.length ? ' ready' : '');

  var cast = STATIONS.filter(function (s) { return assign[s.cs]; }).length;
  $('#m-stations').textContent = STATIONS.length + ' stations \u00b7 ' +
    voices.length + (voices.length === 1 ? ' voice' : ' voices') +
    ' \u00b7 ' + cast + ' cast';
  $('#m-settings').textContent = preset.name + ' \u00b7 ' + minutes + ' min';
}

function refreshAll() {
  var n = chosen().length, total = $$('.chip').length;
  var sm = $('#sel-msg');
  if (sm) sm.textContent = n + ' of ' + total + ' situations turned on';

  buildChannelTable();
  updateVoiceCells();
  updateLoadPanel(null);
  compose();
  refreshMenu();
  saveState();
}

// ==========================================================================
// EXPORTS
// ==========================================================================

function exportCsv() {
  if (!session || !session.tx.length) return;
  var rows = [['time_s','mm:ss','channel','station','source','message',
               'situation','thread_id','exercise_marked']];
  session.tx.forEach(function (x) {
    rows.push([x.t.toFixed(2), mmss(x.t), x.ch, x.cs, x.src,
      '"' + x.text.replace(/"/g,'""') + '"', x.scen, x.thread || '',
      x.ex ? 'yes' : 'no']);
  });
  download('session_log.csv',
    rows.map(function (r) { return r.join(','); }).join('\n'), 'text/csv');
}

function exportPlans() {
  if (!session || !session.tx.length) return;
  var plans = {};
  session.tx.forEach(function (x) {
    (plans[x.cs] = plans[x.cs] || []).push({
      at:+x.t.toFixed(2), channel:x.ch, text:x.text,
      duration:+x.dur.toFixed(2), source:x.src,
      thread_id:x.thread, exercise_marked:!!x.ex
    });
  });
  download('node_plans.json', JSON.stringify({
    seed:seedVal, duration_s:session.dur,
    exercise_marking: $('#exm').value, channels:CH, plans:plans
  }, null, 2), 'application/json');
}

function exportConfig() {
  download('session_config.json', JSON.stringify({
    preset: preset.id,
    minutes: minutes,
    seed: seedVal,
    people: nPeople,
    occupancy: preset.occ / 100,
    doubling: preset.dbl / 100,
    thread_rate: preset.thread / 100,
    exercise_marking: $('#exm').value,
    topics: Object.keys(topicsOn).filter(function (k) { return topicsOn[k]; }),
    situations: chosen(),
    voice_assignment_mode: autoVoice ? 'automatic' : 'manual',
    voices: voices.map(function (v, i) {
      return { id:v.id, name:v.name || ('voice_' + (i+1)),
               file:'voice_' + (i+1) + '.wav', seconds:+v.secs.toFixed(2) };
    }),
    stations: STATIONS.map(function (s) {
      var v = voiceById(assign[s.cs]);
      return { callsign:s.cs, role:s.role, speaker:s.speaker,
               voice_id: assign[s.cs] || null,
               voice_name: v ? (v.name || '') : null,
               reference:refName(s.cs), profile:s.prof };
    }),
    channels: CH,
    recordings: library.map(function (L, i) {
      /* Each recording is a complete exchange containing every speaker,
         so it has no single callsign. */
      return { id:L.id, name:L.name, topic:L.topic, whole_exchange:true,
               file:'recording_' + (i + 1) + '.wav',
               seconds:+L.secs.toFixed(2) };
    })
  }, null, 2), 'application/json');
}

// ==========================================================================
// WIRE UP
// ==========================================================================


/* Attach a listener only if the element exists, so one missing node never
   stops the rest of the interface from wiring up. */
function bind(sel, ev, fn) {
  var el = document.querySelector(sel);
  if (el) el.addEventListener(ev, fn);
  else if (window.console) console.warn('missing element', sel);
}

/* Start with the everyday topics on — the sensible default for anyone who
   opens this and presses go without reading anything. */
topicsOn.checks = true;
topicsOn.movement = true;
topicsOn.supply = true;

function boot() {
  buildCats();
  applyTopics();
  rebuildRoster();
  buildVoices();
  buildPeople('rec-people', 'rec-people-h');
  buildPeople('gen-people', 'gen-people-h');
  buildPeopleGrid();
  buildTakeList();
  buildTopics('rec-topics');
  buildTopics('gen-topics');
  buildPresets();
  buildLengths();
  buildVoicePanel();
  updateLoadPanel(null);
  updateSavedNote();
  compose();
  refreshMenu();
}

/* Open the store, restore anything saved, then build the interface. If the
   database is unavailable the app still runs — it just will not remember
   anything between visits. */
checkVersions();

/* Order matters: find out whether the server is there BEFORE restoring, so
   loadState knows which copy to trust. */
checkServer()
  .then(function (up) { if (up) checkRadios(false); return openDb(); })
  .then(function () { return loadState(); })
  .catch(function () { return false; })
  .then(function () {
    try { boot(); } catch (err) { fail('startup', err); }
  });

/* One delegated handler for every navigation button. Guarded, because
   e.target can be a text node in some browsers and closest() would throw. */
document.addEventListener('click', function (e) {
  var el = e.target;
  if (!el || el.nodeType !== 1) el = el && el.parentElement;
  if (!el) return;

  var b = el.closest ? el.closest('[data-go]')
                     : null;

  /* Fallback for very old engines with no Element.closest */
  if (!b && !el.closest) {
    var n = el;
    while (n && n !== document) {
      if (n.getAttribute && n.getAttribute('data-go')) { b = n; break; }
      n = n.parentNode;
    }
  }

  if (!b) return;
  e.preventDefault();
  go(b.getAttribute('data-go'), { src: b.getAttribute('data-src') });
});

bind('#home-btn', 'click', goBack);

bind('#rec-btn', 'click', startFreeRecording);

bind('#load-file', 'change', function () {
  var f = this.files && this.files[0];
  if (!f) return;
  var reader = new FileReader();
  reader.onload = function () {
    var r = loadPool(reader.result, f.name);
    if (r.error) {
      updateLoadPanel(r.error, true);
      return;
    }
    updateLoadPanel(null);
    compose();
    refreshMenu();
  };
  reader.onerror = function () {
    updateLoadPanel('Could not read that file.', true);
  };
  reader.readAsText(f);
  this.value = '';   // allow re-picking the same file
});

bind('#load-clear', 'click', function () {
  pool = null;
  poolName = '';
  updateLoadPanel(null);
  compose();
  refreshMenu();
});

/* Hand the schedule to the server and let it produce the session WAVs.
   The console already knows what happens when, so this only asks for the
   audio — the timing model stays in one place. */
function buildRealSession(src, btn, noteEl) {
  var sess = (src === 'recorded')
    ? schedule('recorded', rng(seedVal))
    : written;

  if (!sess || !sess.tx.length) {
    noteEl.innerHTML = '<span class="bad">Nothing to build yet.</span>';
    return;
  }
  if (!server.up) {
    noteEl.innerHTML = '<span class="bad">The server is not running.</span> ' +
      'Start it with <span class="mono">python server.py</span> and reload.';
    return;
  }

  var profiles = {};
  STATIONS.forEach(function (st) { profiles[st.cs] = st.prof; });

  var voiceMap = {};
  STATIONS.forEach(function (st) {
    if (assign[st.cs]) voiceMap[st.cs] = assign[st.cs];
  });

  var payload = {
    duration_s: sess.dur,
    exercise_marking: $('#exm') ? $('#exm').value : 'both',
    channels: CH,
    profiles: profiles,
    voice_assignment: voiceMap,
    transmissions: sess.tx.map(function (x) {
      return { t: +x.t.toFixed(2), ch: x.ch, cs: x.cs, text: x.text,
               dur: +x.dur.toFixed(2), src: x.src,
               recording_id: x.recording_id || null,
               profile: profiles[x.cs] || 'handheld' };
    })
  };

  btn.disabled = true;
  var label = btn.textContent;
  btn.textContent = 'Building\u2026';

  runJob('/api/render-session', payload, function (j) {
    var pct = j.total ? Math.round(j.done / j.total * 100) : 0;
    noteEl.innerHTML = 'Working on your machine \u2014 ' + esc(j.step || '') +
      ' (' + pct + '%)';
  })
    .then(function (j) {
      /* Pick up the transmit plan so the radios page can send it. */
      var planFile = (j.files || []).filter(function (f) {
        return f.indexOf('transmit_plan') === 0;
      })[0];
      loadOutputFiles();
      if (planFile) {
        fetch('/api/download/' + encodeURIComponent(planFile))
          .then(function (r) { return r.json(); })
          .then(function (p) { lastPlan = p; drawRadios(); })
          .catch(function () {});
      }

      var links = j.files.map(function (f) {
        return '<a href="/api/download/' + encodeURIComponent(f) + '" download>' +
               esc(f) + '</a>';
      }).join('<br>');
      noteEl.innerHTML = '<span class="ok-t">Done.</span> Written to ' +
        '<span class="mono">' + esc(server.out) + '</span><br>' + links;
      btn.disabled = false; btn.textContent = label;
    })
    .catch(function (err) {
      noteEl.innerHTML = '<span class="bad">' + esc(err.message) + '</span>';
      btn.disabled = false; btn.textContent = label;
    });
}

bind('#gen-build', 'click', function () {
  buildRealSession('generated', this, $('#gen-build-note'));
});

bind('#rec-build', 'click', function () {
  buildRealSession('recorded', this, $('#rec-build-note'));
});

bind('#gen-save', 'click', function () {
  if (!written || !written.tx.length) return;

  var lines = [
    'NET CONTROL — written session',
    'Preset: ' + preset.name + '   Length: ' + minutes + ' minutes' +
      '   Seed: ' + seedVal,
    'Messages: ' + written.tx.length,
    'EXERCISE — SIMULATION ONLY',
    '',
    '-'.repeat(74),
    ''
  ];
  written.tx.forEach(function (x) {
    lines.push(mmss(x.t) + '  ' + (x.ch === 'COMMAND' ? 'CMD' : 'ADM') +
      '  ' + (x.cs + '        ').slice(0, 10) + '  ' +
      (x.ex ? 'EXERCISE. ' : '') + x.text);
  });
  lines.push('');
  lines.push('-'.repeat(74));
  lines.push('Generated ' + new Date().toLocaleString());

  download('session_script.txt', lines.join('\n'), 'text/plain');
});

bind('#gen-again', 'click', function () {
  seedVal = Math.floor(Math.random() * 9999);
  compose();
  refreshMenu();
});

bind('#exm', 'change', refreshAll);
bind('#sel-all', 'click', function () { setAll(function () { return true; }); });
bind('#sel-none', 'click', function () { setAll(function () { return false; }); });
bind('#sel-routine', 'click', function () {
  setAll(function (id) { return INCIDENT.indexOf(id) < 0; });
});

bind('#roster-add', 'click', function () {
  var msg = $('#roster-msg');
  if (STATIONS.length >= ALL_STATIONS.length) {
    if (msg) msg.innerHTML = '<span class="bad">' + ALL_STATIONS.length +
      ' stations is the maximum.</span>';
    return;
  }
  setPeople(STATIONS.length + 1);
  buildPeople('rec-people', 'rec-people-h');
  buildPeople('gen-people', 'gen-people-h');
  buildPeopleGrid();
  buildTakeList();
  buildVoicePanel();
  if (msg) msg.textContent = 'Added ' + STATIONS[STATIONS.length - 1].cs +
    '. Now ' + STATIONS.length + ' stations.';
});

bind('#roster-reset', 'click', function () {
  if (voices.length && !window.confirm(
        'This deletes every recorded voice and restores the default stations. ' +
        'Continue?')) return;

  voices.forEach(function (v) { URL.revokeObjectURL(v.url); });
  voices = [];
  assign = {};
  refs = {};
  autoVoice = true;

  /* Genuinely back to the default roster, not whatever the count happens
     to be after stations were added. */
  STATIONS = JSON.parse(JSON.stringify(ALL_STATIONS)).slice(0, 6);
  nPeople = 6;

  rebuildRoster();
  buildVoices();
  buildVoicePanel();
  buildPeople('rec-people', 'rec-people-h');
  buildPeople('gen-people', 'gen-people-h');
  buildPeopleGrid();
  buildTakeList();
  refreshAll();
});

bind('#p-play', 'click', startPlayback);
bind('#p-stop', 'click', function () {
  stopPlayback();
  resetPlayback();
});
bind('#p-speed', 'change', function () {
  var was = playing;
  if (was) pausePlayback();
  speed = parseFloat(this.value);
  if (was) startPlayback();
});
bind('#p-sound', 'change', function () {
  soundOn = this.checked;
  if (!soundOn) stopAudio();
});

bind('#scrub', 'click', function (e) {
  if (!session) return;
  var r = this.getBoundingClientRect();
  var pc = Math.max(0, Math.min(1, (e.clientX - r.left) / r.width));
  var was = playing;
  stopPlayback();
  playPos = pc * session.dur;
  playIdx = 0;
  $('#p-log').innerHTML = '';
  while (playIdx < session.tx.length && session.tx[playIdx].t < playPos) playIdx++;
  $('#p-clock').textContent = mmss(playPos);
  updateScrub();
  if (was) startPlayback();
});

bind('#dl-csv', 'click', exportCsv);
bind('#dl-csv2', 'click', function () {
  if (!session) session = written;
  exportCsv();
});
bind('#dl-plan', 'click', function () {
  if (!session) session = written;
  exportPlans();
});
bind('#dl-cfg', 'click', exportConfig);

bind('#sdr-refresh', 'click', function () {
  var m = $('#sdr-msg');
  if (m) m.textContent = 'looking\u2026';
  checkRadios(true);
});

bind('#tx-go', 'click', transmitSession);
bind('#mix-go', 'click', sendMixed);

bind('#mix-repeat', 'change', function () {
  var on = this.checked;
  var fld = $('#mix-repeat-pause-fld'), hint = $('#mix-repeat-hint');
  if (fld) fld.style.display = on ? '' : 'none';
  if (hint) hint.style.display = on ? '' : 'none';
});

bind('#mix-stop', 'click', function () {
  $('#mix-result').innerHTML = 'Stopping after the current pass\u2026';
  this.disabled = true;
  stopJob(currentMixJob);
});
bind('#mix-file', 'change', mixNote);
bind('#tx-radio', 'change', updateLinkLabel);
bind('#rx-radio', 'change', updateLinkLabel);

bind('#tx-stop', 'click', function () {
  /* The server finishes the chunk/clip it is on; this just asks it to
     stop after that rather than continuing to the next one. */
  $('#tx-note').innerHTML = 'Stopping after the current transmission\u2026';
  this.disabled = true;
  stopJob(currentSessionJob);
});

try {
  go('home');
  if (window.console) console.log('Net Control ' + NET_CONTROL_VERSION + ' ready');
} catch (err) {
  fail('opening the menu', err);
}

bind('#clear-saved', 'click', function () {
  if (!window.confirm('This deletes every recording and voice stored on this ' +
      'computer, and all your settings. It cannot be undone. Continue?')) return;

  var wipeServer = server.up
    ? fetch('/api/state/clear', { method: 'POST' }).catch(function () {})
    : Promise.resolve();

  wipeServer.then(dbClear).then(function () { location.reload(); });
});

})();
